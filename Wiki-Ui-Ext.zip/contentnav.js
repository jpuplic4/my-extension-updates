// Block 1: Navigation Tree Logic (Keep the existing IIFE wrapping this part)
(() => {
  'use strict';


  // ==============================
  // PASTE YOUR NAV / VIEW SCRIPTS HERE
  // ==============================
  //
  // - Navigation tree
  // - Page builder
  // - API-backed nav
  // - Read-only helpers
  //
  // IMPORTANT:
  // - Remove all // ==UserScript== headers
  // - Remove @match, @run-at
  //
  // Configuration
  const NAV_API_URL = 'http://eapw-105:22001/api/navigation/tree';
  const WIKI_BASE = 'http://eapw-105:20001';

  let navDataTree = null;
  let expandedPaths = new Set();

  // Get all parent paths for a given path
  function getParentPaths(path) {
    const parents = [];
    const parts = path.split('/');

    for (let i = 1; i < parts.length; i++) {
      parents.push(parts.slice(0, i).join('/'));
    }

    return parents;
  }
  
  // Auto-expand tree to show current page
  function autoExpandToCurrentPage(currentPath) {
    // Get all parent paths and expand them
    const parents = getParentPaths(currentPath);
    parents.forEach(parent => {
      expandedPaths.add(parent);
    });

    // Also expand the current page itself if it has children
    expandedPaths.add(currentPath);

  }

  // Get current page path (normalized)
  function getCurrentPath() {
    const pathname = window.location.pathname;
    // Remove leading /en/ or other language prefix
    const match = pathname.match(/^\/[a-z]{2}\/(.*)/);
    return match ? match[1] : pathname.replace(/^\//, '');
  }

  // Fetch navigation tree from API and build virtual tree
  async function fetchNavigationTree() {
    try {
      const response = await fetch(NAV_API_URL);
      const data = await response.json();

      if (data.success) {
        navDataTree = buildVirtualTree(data.data);
        return navDataTree;
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  // Build virtual tree with inferred folders
  function buildVirtualTree(pages) {
    const pageMap = {};
    const tree = {};

    // Filter out same-named child pages (e.g. "testing/testing") - these exist
    // only to make Wiki.js treat the parent as a folder, they are not real content.
    pages = pages.filter(page => {
      const parts = page.path.split('/');
      if (parts.length < 2) return true;
      return parts[parts.length - 1] !== parts[parts.length - 2];
    });

    // Index all pages by path (includes sortOrder from API)
    pages.forEach(page => {
      pageMap[page.path] = page;
    });

    // Build tree structure - create all nodes including virtual folders
    pages.forEach(page => {
      const parts = page.path.split('/');

      // Create all parent folders for this page
      for (let i = 1; i <= parts.length; i++) {
        const currentPath = parts.slice(0, i).join('/');

        if (!tree[currentPath]) {
          // Check if this path has an actual page
          const pageData = pageMap[currentPath];

          tree[currentPath] = {
            path: currentPath,
            title: pageData ? pageData.title : formatFolderName(parts[i - 1]),
            hasPage: !!pageData,
            id: pageData ? pageData.id : null,
            sortOrder: pageData ? (pageData.sortOrder || 0) : 0,
            children: []
          };
        }
      }
    });

    // Build parent-child relationships
    const roots = [];
    const allNodes = Object.values(tree);

    allNodes.forEach(node => {
      const parts = node.path.split('/');

      if (parts.length === 1) {
        // Root level node
        roots.push(node);
      } else {
        // Child node - find parent
        const parentPath = parts.slice(0, -1).join('/');
        const parent = tree[parentPath];

        if (parent && !parent.children.some(c => c.path === node.path)) {
          parent.children.push(node);
        }
      }
    });

    // Sort children by sortOrder (falls back to title for equal sortOrder)
    // "home" is always pinned first at root level
    function sortChildren(nodes, isRoot = false) {
      nodes.sort((a, b) => {
        // At root level, "home" always comes first
        if (isRoot) {
          if (a.path === 'home') return -1;
          if (b.path === 'home') return 1;
        }
        const orderDiff = (a.sortOrder || 0) - (b.sortOrder || 0);
        if (orderDiff !== 0) return orderDiff;
        return a.title.localeCompare(b.title);
      });
      nodes.forEach(node => {
        if (node.children && node.children.length > 0) {
          sortChildren(node.children, false);
        }
      });
    }

    sortChildren(roots, true);

    return roots;
  }

  // Format folder name from path segment (sql-smartsheet → Sql Smartsheet)
  function formatFolderName(segment) {
    return segment
      .split('-')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }

  // Toggle folder expand/collapse
  function toggleFolder(path) {
    if (expandedPaths.has(path)) {
      expandedPaths.delete(path);
    } else {
      expandedPaths.add(path);
    }
    renderNavigation();
  }

  // Special pinned page - always at top, not draggable, no subpages allowed
  const PINNED_HOME_PATH = 'home';

  // Build tree HTML recursively
  function buildTreeHTML(nodes, currentPath) {
    if (!nodes || nodes.length === 0) return '';

    let html = '<ul class="wiki-nav-tree">';

    nodes.forEach(node => {
      const hasChildren = node.children && node.children.length > 0;
      const isExpanded = expandedPaths.has(node.path);
      const isCurrent = node.path === currentPath;
      const pageUrl = `${WIKI_BASE}/en/${node.path}`;
      const isPinned = node.path === PINNED_HOME_PATH;

      if (hasChildren) {
        const chevron = isExpanded ? '▼' : '▶';

        if (node.hasPage) {
          // Has children AND a page - show as clickable folder+page
          // Pinned page: not draggable, no drop target (can't drop into it)
          html += `
            <li class="nav-folder ${isExpanded ? 'expanded' : 'collapsed'} ${isPinned ? 'pinned-home' : ''}" ${isPinned ? '' : `draggable="true" data-drag-path="${node.path}" data-drag-type="folder"`}>
              <div class="nav-folder-header" ${isPinned ? '' : `data-drop-target="${node.path}" data-drop-type="folder"`}>
                <span class="chevron-toggle" data-path="${node.path}">${chevron}</span>
                <a href="${pageUrl}" class="nav-folder-link ${isCurrent ? 'current' : ''}" data-path="${node.path}">
                  <span class="folder-icon">${isPinned ? '🏠' : '📁'}</span>
                  <span class="folder-name">${node.title}</span>
                </a>
              </div>
              ${isExpanded ? buildTreeHTML(node.children, currentPath) : ''}
            </li>
          `;
        } else {
          // Has children but NO page - show as non-clickable folder only
          html += `
            <li class="nav-folder ${isExpanded ? 'expanded' : 'collapsed'}">
              <div class="nav-folder-header" data-drop-target="${node.path}" data-drop-type="virtual-folder">
                <span class="chevron-toggle" data-path="${node.path}">${chevron}</span>
                <span class="nav-folder-label">
                  <span class="folder-icon">📁</span>
                  <span class="folder-name">${node.title}</span>
                </span>
              </div>
              ${isExpanded ? buildTreeHTML(node.children, currentPath) : ''}
            </li>
          `;
        }
      } else {
        // Page item (leaf node - no children)
        // Pinned page: not draggable
        html += `
          <li class="nav-page ${isPinned ? 'pinned-home' : ''}" ${isPinned ? '' : `draggable="true" data-drag-path="${node.path}" data-drag-type="page"`}>
            <a href="${pageUrl}" class="nav-page-link ${isCurrent ? 'current' : ''}" ${isPinned ? '' : `data-drop-target="${node.path}" data-drop-type="page"`}>
              <span class="page-icon">${isPinned ? '🏠' : '📄'}</span>
              <span class="page-name">${node.title}</span>
            </a>
          </li>
        `;
      }
    });

    html += '</ul>';
    return html;
  }

  // Render the navigation tree
  function renderNavigation() {
    if (!navDataTree) return;

    const navContainer = document.getElementById('wiki-nav-tree-container');
    if (!navContainer) return;

    const currentPath = getCurrentPath();
    const treeHtml = buildTreeHTML(navDataTree, currentPath);

    // Add drop zones at top and bottom for root-level drops
    const html = `
      <div class="root-drop-zone root-drop-zone-top" data-drop-target="__ROOT__" data-drop-type="root-top">
        Drop here for root level
      </div>
      ${treeHtml}
      <div class="root-drop-zone root-drop-zone-bottom" data-drop-target="__ROOT__" data-drop-type="root-bottom">
        Drop here for root level
      </div>
    `;

    navContainer.innerHTML = html;

    // Add click handlers to chevrons
    navContainer.querySelectorAll('.chevron-toggle').forEach(chevron => {
      chevron.addEventListener('click', (e) => {
        e.preventDefault();
        const path = e.target.dataset.path;
        toggleFolder(path);
      });
    });

    // Initialize drag-and-drop handlers
    initDragAndDrop(navContainer);
  }

  // Drag and drop state
  let draggedPath = null;
  let draggedType = null;

  // Initialize drag and drop event handlers
  function initDragAndDrop(container) {
    // Dragstart - when user starts dragging an item
    container.addEventListener('dragstart', (e) => {
      const draggableItem = e.target.closest('[data-drag-path]');
      if (!draggableItem) return;

      draggedPath = draggableItem.dataset.dragPath;
      draggedType = draggableItem.dataset.dragType;

      // Add visual feedback
      draggableItem.classList.add('dragging');

      // Show root drop zones
      container.querySelectorAll('.root-drop-zone').forEach(zone => {
        zone.classList.add('drag-active');
      });

      // Set drag data
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', draggedPath);
    });

    // Dragend - when drag operation ends
    container.addEventListener('dragend', (e) => {
      if (!(e.target instanceof Element)) return;
      const draggableItem = e.target.closest('[data-drag-path]');
      if (draggableItem) {
        draggableItem.classList.remove('dragging');
      }

      // Clean up all drop indicators
      container.querySelectorAll('.drop-target, .drop-indicator-above, .drop-indicator-below, .drop-indicator-inside').forEach(el => {
        el.classList.remove('drop-target', 'drop-indicator-above', 'drop-indicator-below', 'drop-indicator-inside');
      });

      // Hide root drop zones
      container.querySelectorAll('.root-drop-zone').forEach(zone => {
        zone.classList.remove('drag-active');
      });

      draggedPath = null;
      draggedType = null;
    });

    // Dragover - when dragging over a potential drop target
    container.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';

      if (!(e.target instanceof Element)) return;
      const dropTarget = e.target.closest('[data-drop-target]');
      if (!dropTarget) return;

      const targetPath = dropTarget.dataset.dropTarget;
      const targetType = dropTarget.dataset.dropType;

      // Don't allow dropping on itself or its children (skip for root zones)
      if (targetPath !== '__ROOT__' && (targetPath === draggedPath || targetPath.startsWith(draggedPath + '/'))) {
        e.dataTransfer.dropEffect = 'none';
        return;
      }

      // Clear previous indicators
      container.querySelectorAll('.drop-target, .drop-indicator-above, .drop-indicator-below, .drop-indicator-inside').forEach(el => {
        el.classList.remove('drop-target', 'drop-indicator-above', 'drop-indicator-below', 'drop-indicator-inside');
      });

      // Handle root drop zones - just highlight them
      if (targetType === 'root-top' || targetType === 'root-bottom') {
        dropTarget.classList.add('drop-target');
        return;
      }

      // Determine drop position based on mouse position
      const rect = dropTarget.getBoundingClientRect();
      const mouseY = e.clientY;
      const relativeY = mouseY - rect.top;
      const height = rect.height;

      if (targetType === 'folder' || targetType === 'virtual-folder') {
        // For folders: top 25% = above, middle 50% = inside, bottom 25% = below
        if (relativeY < height * 0.25) {
          dropTarget.classList.add('drop-indicator-above');
        } else if (relativeY > height * 0.75) {
          dropTarget.classList.add('drop-indicator-below');
        } else {
          dropTarget.classList.add('drop-indicator-inside');
        }
      } else {
        // For pages: top 50% = above, bottom 50% = below
        if (relativeY < height * 0.5) {
          dropTarget.classList.add('drop-indicator-above');
        } else {
          dropTarget.classList.add('drop-indicator-below');
        }
      }

      dropTarget.classList.add('drop-target');
    });

    // Dragleave - when leaving a drop target
    container.addEventListener('dragleave', (e) => {
      if (!(e.target instanceof Element)) return;
      const dropTarget = e.target.closest('[data-drop-target]');
      if (dropTarget && !dropTarget.contains(e.relatedTarget)) {
        dropTarget.classList.remove('drop-target', 'drop-indicator-above', 'drop-indicator-below', 'drop-indicator-inside');
      }
    });

    // Drop - when item is dropped
    container.addEventListener('drop', async (e) => {
      e.preventDefault();

      if (!(e.target instanceof Element)) return;
      const dropTarget = e.target.closest('[data-drop-target]');
      if (!dropTarget || !draggedPath) return;

      // Save draggedPath to local variable immediately (before any async operations)
      // because dragend event may fire and set draggedPath to null during async calls
      const sourcePath = draggedPath;

      const targetPath = dropTarget.dataset.dropTarget;
      const targetType = dropTarget.dataset.dropType;

      // Don't allow dropping on itself or its children (skip for root zones)
      if (targetPath !== '__ROOT__' && (targetPath === sourcePath || targetPath.startsWith(sourcePath + '/'))) {
        return;
      }

      // Calculate the new path and sortOrder
      const draggedName = sourcePath.split('/').pop();
      let newPath;
      let dropPosition = 'inside';
      let targetParentPath = '';

      // Handle root drop zones - move to root level
      if (targetType === 'root-top' || targetType === 'root-bottom') {
        newPath = draggedName;
        targetParentPath = '';
        dropPosition = targetType === 'root-top' ? 'above' : 'below';
      } else {
        // Determine drop position
        const rect = dropTarget.getBoundingClientRect();
        const mouseY = e.clientY;
        const relativeY = mouseY - rect.top;
        const height = rect.height;

        if (targetType === 'folder' || targetType === 'virtual-folder') {
          if (relativeY < height * 0.25) {
            dropPosition = 'above';
          } else if (relativeY > height * 0.75) {
            dropPosition = 'below';
          } else {
            dropPosition = 'inside';
          }
        } else {
          dropPosition = relativeY < height * 0.5 ? 'above' : 'below';
        }

        if (dropPosition === 'inside') {
          // Move inside the folder
          newPath = targetPath + '/' + draggedName;
          targetParentPath = targetPath;
        } else {
          // Move as sibling (above or below)
          targetParentPath = targetPath.includes('/') ? targetPath.substring(0, targetPath.lastIndexOf('/')) : '';
          newPath = targetParentPath ? targetParentPath + '/' + draggedName : draggedName;
        }

      }

      // Clean up UI
      dropTarget.classList.remove('drop-target', 'drop-indicator-above', 'drop-indicator-below', 'drop-indicator-inside');

      // Calculate sortOrder based on drop position (pass sourcePath to exclude from siblings)
      const sortOrder = await calculateSortOrder(targetPath, targetParentPath, dropPosition, targetType, sourcePath);

      // Check if this is just a reorder (same path) or a move (different path)
      if (sourcePath === newPath) {
        // Same path - just reorder within the same folder
        if (typeof sortOrder === 'number') {
          await reorderPageViaAPI(sourcePath, sortOrder);
        }
        return;
      }

      // Call move API with sortOrder
      await movePageViaAPI(sourcePath, newPath, sortOrder);
    });
  }

  // Calculate the sortOrder for the dropped item
  async function calculateSortOrder(targetPath, parentPath, dropPosition, targetType, sourcePath) {
    const API_URL = 'http://eapw-105:22001';

    try {
      // Get siblings at the destination
      const response = await fetch(`${API_URL}/api/pages/siblings?parentPath=${encodeURIComponent(parentPath)}`);
      const data = await response.json();

      if (!data.success) return null;

      // Filter out the item being moved (important for same-folder reorder)
      let siblings = data.siblings.filter(s => s.path !== sourcePath);

      // Handle special cases
      if (siblings.length === 0) {
        return 10; // First item in folder
      }

      // Check if sortOrders need normalization (all same value or gaps too small).
      // Require at least 2 siblings — a single-element array is vacuously "all equal"
      // and should not trigger a normalization round-trip.
      const needsNormalization = siblings.length >= 2 && (
        siblings.every(s => s.sortOrder === siblings[0].sortOrder) ||
        siblings.some((s, i) => i > 0 && Math.abs(s.sortOrder - siblings[i-1].sortOrder) < 2)
      );

      if (needsNormalization) {
        // Normalize sortOrders: assign 10, 20, 30, etc.
        await normalizeSiblingOrder(parentPath, siblings);
        // Reproduce normalized values locally instead of a second round-trip:
        // normalizeSiblingOrder sorts home=0 at root, everything else (index+1)*10
        const isRootLevel = !parentPath || parentPath === '';
        const sorted = [...siblings].sort((a, b) => {
          if (isRootLevel && a.path === 'home') return -1;
          if (isRootLevel && b.path === 'home') return 1;
          return (a.sortOrder || 0) - (b.sortOrder || 0);
        });
        siblings = sorted.map((s, i) => ({
          ...s,
          sortOrder: (isRootLevel && s.path === 'home') ? 0 : (i + 1) * 10
        }));
      }

      // For root drop zones
      if (targetType === 'root-top') {
        // At root level, "home" is pinned first - place after it
        const homeIndex = siblings.findIndex(s => s.path === 'home');
        if (homeIndex !== -1 && siblings.length > 1) {
          // Place between home and the next item
          const homeOrder = siblings[homeIndex].sortOrder;
          const nextOrder = siblings[homeIndex + 1]?.sortOrder || homeOrder + 20;
          return Math.floor((homeOrder + nextOrder) / 2);
        }
        return Math.max(1, siblings[0].sortOrder - 10);
      }

      if (targetType === 'root-bottom') {
        return siblings[siblings.length - 1].sortOrder + 10;
      }

      // For dropping inside a folder, append to end
      if (dropPosition === 'inside') {
        return siblings[siblings.length - 1].sortOrder + 10;
      }

      // Find the target in siblings
      const targetIndex = siblings.findIndex(s => s.path === targetPath);

      if (targetIndex === -1) {
        // Target not found, append to end
        return siblings[siblings.length - 1].sortOrder + 10;
      }

      if (dropPosition === 'above') {
        if (targetIndex === 0) {
          // Dropping above first item
          return Math.max(1, siblings[0].sortOrder - 10);
        } else {
          // Calculate midpoint between previous and target
          const prevOrder = siblings[targetIndex - 1].sortOrder;
          const targetOrder = siblings[targetIndex].sortOrder;
          const midpoint = Math.floor((prevOrder + targetOrder) / 2);
          // If midpoint equals prev, we need more space - use prev + 1
          if (midpoint <= prevOrder) {
            return prevOrder + 1;
          }
          return midpoint;
        }
      } else if (dropPosition === 'below') {
        if (targetIndex === siblings.length - 1) {
          // Dropping below last item
          return siblings[targetIndex].sortOrder + 10;
        } else {
          // Calculate midpoint between target and next
          const targetOrder = siblings[targetIndex].sortOrder;
          const nextOrder = siblings[targetIndex + 1].sortOrder;
          const midpoint = Math.floor((targetOrder + nextOrder) / 2);
          // If midpoint equals target, we need more space - use target + 1
          if (midpoint <= targetOrder) {
            return targetOrder + 1;
          }
          return midpoint;
        }
      }

      return null;
    } catch (error) {
      console.error('[Nav] calculateSortOrder error:', error);
      return null;
    }
  }

  // Normalize sibling sortOrders to have even spacing
  // "home" stays at 0 if at root level, others get 10, 20, 30...
  async function normalizeSiblingOrder(parentPath, siblings) {
    const API_URL = 'http://eapw-105:22001';
    const isRoot = !parentPath || parentPath === '';

    try {
      // Sort: home first (at root), then by current sortOrder
      const sorted = [...siblings].sort((a, b) => {
        if (isRoot) {
          if (a.path === 'home') return -1;
          if (b.path === 'home') return 1;
        }
        return (a.sortOrder || 0) - (b.sortOrder || 0);
      });

      // Assign new sortOrders: home=0, others=10, 20, 30...
      const orders = sorted.map((s, index) => ({
        path: s.path,
        sortOrder: (isRoot && s.path === 'home') ? 0 : (index + 1) * 10
      }));

      await fetch(`${API_URL}/api/pages/reorder`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orders })
      });

      console.log('[Nav] Normalized sortOrder for', orders.length, 'siblings');
    } catch (error) {
      console.error('[Nav] normalizeSiblingOrder error:', error);
    }
  }

  // Apply a sortOrder change directly to navDataTree so we can re-render
  // instantly without waiting for a full server round-trip.
  function applyOptimisticReorder(path, newSortOrder) {
    if (!navDataTree) return;
    function updateInNodes(nodes) {
      const idx = nodes.findIndex(n => n.path === path);
      if (idx !== -1) {
        nodes[idx] = { ...nodes[idx], sortOrder: newSortOrder };
        nodes.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0) || a.title.localeCompare(b.title));
        return true;
      }
      for (const node of nodes) {
        if (node.children && updateInNodes(node.children)) return true;
      }
      return false;
    }
    updateInNodes(navDataTree);
  }

  // Call the reorder API (just update sortOrder, no path change)
  async function reorderPageViaAPI(path, sortOrder) {
    const API_URL = 'http://eapw-105:22001';

    // 1. Apply optimistically so the UI updates immediately
    applyOptimisticReorder(path, sortOrder);
    autoExpandToCurrentPage(getCurrentPath());
    renderNavigation();

    try {
      const response = await fetch(`${API_URL}/api/pages/reorder`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orders: [{ path: path, sortOrder: sortOrder }]
        })
      });

      const result = await response.json();

      if (result.success) {
        showMoveNotification(`Reordered "${path.split('/').pop()}"`, 'success');
        // Background sync to confirm server state
        fetchNavigationTree().then(() => renderNavigation());
      } else {
        // Revert
        await fetchNavigationTree();
        renderNavigation();
        showMoveNotification(`Reorder failed: ${result.error}`, 'error');
      }
    } catch (error) {
      await fetchNavigationTree();
      renderNavigation();
      showMoveNotification(`Reorder error: ${error.message}`, 'error');
    }
  }

  // Call the move API
  async function movePageViaAPI(sourcePath, destPath, sortOrder) {
    const API_URL = 'http://eapw-105:22001';

    try {
      const body = { sourcePath, destPath };
      if (typeof sortOrder === 'number') body.sortOrder = sortOrder;

      const response = await fetch(`${API_URL}/api/pages/move`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      const result = await response.json();

      if (result.success) {
        showMoveNotification(`Moved "${sourcePath.split('/').pop()}"`, 'success');
        // Background sync (move changes paths so we need a full re-fetch)
        fetchNavigationTree().then(() => {
          autoExpandToCurrentPage(getCurrentPath());
          renderNavigation();
        });
      } else {
        showMoveNotification(`Move failed: ${result.error}`, 'error');
      }
    } catch (error) {
      showMoveNotification(`Move error: ${error.message}`, 'error');
    }
  }

  // Show a notification for move operations
  function showMoveNotification(message, type) {
    // Remove existing notification
    const existing = document.getElementById('wiki-nav-notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.id = 'wiki-nav-notification';
    notification.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      padding: 12px 20px;
      border-radius: 6px;
      font-size: 14px;
      z-index: 10001;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      transition: opacity 0.3s;
      ${type === 'success'
        ? 'background: #4CAF50; color: white;'
        : 'background: #f44336; color: white;'}
    `;
    notification.textContent = message;

    document.body.appendChild(notification);

    // Auto-remove after 3 seconds
    setTimeout(() => {
      notification.style.opacity = '0';
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }

  // Inject navigation tree into sidebar
  function injectNavigationTree(retryCount = 0) {
    const navDrawer = document.querySelector('.v-navigation-drawer');
    if (!navDrawer) {
      if (retryCount < 10) {
        setTimeout(() => injectNavigationTree(retryCount + 1), 500);
        return;
      }
      return;
    }

    // Check if already injected
    if (document.getElementById('wiki-nav-tree-container')) return;

    // Add styles first
    injectNavigationStyles();

    // Create container
    const container = document.createElement('div');
    container.id = 'wiki-nav-tree-container';

    // Find the existing nav list and REPLACE it (not just append)
    const existingNav = navDrawer.querySelector('.v-list');
    if (existingNav) {
      existingNav.parentNode.replaceChild(container, existingNav);
    } else {
      navDrawer.appendChild(container);
    }

    // Fetch and render tree
    fetchNavigationTree().then(() => {
      const currentPath = getCurrentPath();
      autoExpandToCurrentPage(currentPath);
      renderNavigation();
    });
  }

  // Inject navigation styles
  function injectNavigationStyles() {
    const style = document.createElement('style');
    style.textContent = `
      #wiki-nav-tree-container {
        padding: 8px 0;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        color: #fff;
      }

      .wiki-nav-tree {
        list-style: none !important;
        padding-left: 4px !important;
        margin: 0 !important;
      }

      .wiki-nav-tree ul {
        list-style: none !important;
        padding-left: 16px !important;
        margin: 0 !important;
      }

      .nav-folder,
      .nav-page {
        margin: 2px 0;
      }

      .nav-folder-header {
        display: flex;
        align-items: center;
        padding: 4px 8px;
        border-radius: 4px;
        transition: background 0.2s;
      }

      .nav-folder-header:hover {
        background: rgba(255, 255, 255, 0.05);
      }

      .chevron-toggle {
        display: inline-block;
        width: 16px;
        font-size: 10px;
        margin-right: 6px;
        color: rgba(255, 255, 255, 0.7);
        cursor: pointer;
        user-select: none;
        padding: 4px;
      }

      .chevron-toggle:hover {
        color: #fff;
      }

      .nav-folder-link {
        display: flex;
        align-items: center;
        flex: 1;
        color: rgba(255, 255, 255, 0.87);
        text-decoration: none;
        border-radius: 4px;
        padding: 2px 6px;
        margin: -2px 0;
        transition: all 0.2s;
      }

      .nav-folder-link:hover {
        background: rgba(255, 255, 255, 0.1);
        color: #fff;
      }

      .nav-folder-link.current {
        font-weight: bold;
        background: rgba(255, 255, 255, 0.15);
        color: #fff;
      }

      .nav-folder-label {
        display: flex;
        align-items: center;
        flex: 1;
        color: rgba(255, 255, 255, 0.87);
        padding: 2px 6px;
        margin: -2px 0;
        cursor: pointer;
        user-select: none;
      }

      .nav-folder-label:hover {
        color: #fff;
      }

      .folder-icon {
        display: inline-block;
        width: 16px;
        margin-right: 8px;
        font-size: 12px;
        opacity: 0.8;
      }

      .folder-name {
        flex: 1;
        color: #fff;
      }

      .nav-page-link {
        display: flex;
        align-items: center;
        padding: 4px 8px;
        padding-left: 26px;
        color: #fff;
        text-decoration: none;
        border-radius: 4px;
        transition: all 0.2s;
      }

      .nav-page-link:hover {
        background: rgba(255, 255, 255, 0.1);
        color: #fff;
      }

      .nav-page-link.current {
        font-weight: bold;
        background: rgba(255, 255, 255, 0.15);
        color: #fff;
      }

      .page-icon {
        display: inline-block;
        width: 16px;
        margin-right: 8px;
        font-size: 12px;
        opacity: 0.7;
      }

      .page-name {
        flex: 1;
        color: #fff;
      }

      /* Drag and Drop Styles */
      [draggable="true"] {
        cursor: grab;
      }

      [draggable="true"]:active {
        cursor: grabbing;
      }

      .dragging {
        opacity: 0.5;
        background: rgba(76, 175, 80, 0.2);
      }

      .drop-target {
        position: relative;
      }

      .drop-indicator-above::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: #4CAF50;
        border-radius: 2px;
      }

      .drop-indicator-below::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: #4CAF50;
        border-radius: 2px;
      }

      .drop-indicator-inside {
        background: rgba(76, 175, 80, 0.3) !important;
        outline: 2px dashed #4CAF50;
        outline-offset: -2px;
      }

      .nav-folder-header.drop-target,
      .nav-page-link.drop-target {
        position: relative;
      }

      /* Root level drop zones */
      .root-drop-zone {
        padding: 8px 12px;
        margin: 4px 8px;
        border: 2px dashed rgba(255, 255, 255, 0.2);
        border-radius: 6px;
        text-align: center;
        font-size: 11px;
        color: rgba(255, 255, 255, 0.4);
        transition: all 0.2s;
        opacity: 0;
        height: 0;
        padding: 0;
        margin: 0;
        overflow: hidden;
      }

      .root-drop-zone.drag-active {
        opacity: 1;
        height: auto;
        padding: 8px 12px;
        margin: 4px 8px;
      }

      .root-drop-zone.drop-target {
        border-color: #4CAF50;
        background: rgba(76, 175, 80, 0.2);
        color: #4CAF50;
      }

      /* Pinned home page - not draggable */
      .pinned-home {
        cursor: default !important;
      }

      .pinned-home [draggable] {
        cursor: default !important;
      }

      .pinned-home .nav-folder-header,
      .pinned-home .nav-page-link {
        border-left: 3px solid rgba(255, 193, 7, 0.6);
        padding-left: 5px;
        margin-left: -3px;
      }

      /* Subtle white-grey shimmer on home title */
      .pinned-home .folder-name,
      .pinned-home .page-name {
        animation: subtleShimmer 4s ease-in-out infinite;
      }

      @keyframes subtleShimmer {
        0%, 100% { color: rgba(255, 255, 255, 1); }
        50% { color: rgba(180, 180, 180, 1); }
      }
    `;
    document.head.appendChild(style);
  }

  // Initialize
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectNavigationTree);
  } else {
    injectNavigationTree();
  }
})(); // <--- CLOSE THE NAV TREE IIFE HERE


// ====================================================================================
// PART 2: EDIT SHORTCUT - Press "E" to enter edit mode (IIFE #2)
// ====================================================================================
(() => {
  // Listen for 'e' key press to enter edit mode
  document.addEventListener('keydown', function(e) {
    // Ignore if user is typing in an input field, textarea, or contenteditable
    const activeElement = document.activeElement;
    const isTyping = activeElement.tagName === 'INPUT' ||
                     activeElement.tagName === 'TEXTAREA' ||
                     activeElement.isContentEditable;

    // Check if 'e' or 'E' was pressed (not with modifier keys)
    if ((e.key === 'e' || e.key === 'E') && !isTyping && !e.ctrlKey && !e.metaKey && !e.altKey) {
      e.preventDefault();

      const currentUrl = window.location.pathname;

      // Check if we're on a view page (not already in edit mode)
      if (!currentUrl.startsWith('/e/')) {
        // Insert /e/ before the language code
        // Example: /en/home/page -> /e/en/home/page
        const editUrl = currentUrl.replace(/^\/([a-z]{2})\//, '/e/$1/');
        window.location.href = editUrl;
      }
    }
  });
})();


// ====================================================================================
// PART 3: PAGE BUILDER - NEW PAGE MODAL (IIFE #3)
// ====================================================================================
(() => {
  'use strict';


  // Configuration
  const API_URL = 'http://eapw-105:22001';
  const NAV_API_URL = 'http://eapw-105:22001/api/navigation/tree';

  // Global state
  let builderNavData = null;
  let builderExpandedPaths = new Set();
  let selectedBasePath = '';
  let createdFolders = new Set();

  // Fetch navigation tree for builder modal
  async function fetchBuilderNavigationTree() {
    try {
      const response = await fetch(NAV_API_URL);
      const data = await response.json();

      if (data.success) {
        builderNavData = buildBuilderVirtualTree(data.data);
        renderBuilderNavigationTree();
      }
    } catch (error) {
      // Silent fail - navigation will show empty
    }
  }

  // Build virtual tree (same as nav tree)
  function buildBuilderVirtualTree(pages) {
    const pageMap = {};
    const tree = {};

    pages.forEach(page => {
      pageMap[page.path] = page;
    });

    pages.forEach(page => {
      const parts = page.path.split('/');

      for (let i = 1; i <= parts.length; i++) {
        const currentPath = parts.slice(0, i).join('/');

        if (!tree[currentPath]) {
          const pageData = pageMap[currentPath];

          tree[currentPath] = {
            path: currentPath,
            title: pageData ? pageData.title : formatBuilderFolderName(parts[i - 1]),
            hasPage: !!pageData,
            id: pageData ? pageData.id : null,
            sortOrder: pageData ? (pageData.sortOrder || 0) : 0,
            children: []
          };
        }
      }
    });

    const roots = [];
    const allNodes = Object.values(tree);

    allNodes.forEach(node => {
      const parts = node.path.split('/');

      if (parts.length === 1) {
        roots.push(node);
      } else {
        const parentPath = parts.slice(0, -1).join('/');
        const parent = tree[parentPath];

        if (parent && !parent.children.some(c => c.path === node.path)) {
          parent.children.push(node);
        }
      }
    });

    // Sort by sortOrder (falls back to title for equal sortOrder)
    function sortChildren(nodes) {
      nodes.sort((a, b) => {
        const orderDiff = (a.sortOrder || 0) - (b.sortOrder || 0);
        if (orderDiff !== 0) return orderDiff;
        return a.title.localeCompare(b.title);
      });
      nodes.forEach(node => {
        if (node.children && node.children.length > 0) {
          sortChildren(node.children);
        }
      });
    }

    sortChildren(roots);
    return roots;
  }

  function formatBuilderFolderName(segment) {
    return segment
      .split('-')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }

  // Toggle folder in builder tree
  function toggleBuilderFolder(path) {
    if (builderExpandedPaths.has(path)) {
      builderExpandedPaths.delete(path);
    } else {
      builderExpandedPaths.add(path);
    }
    renderBuilderNavigationTree();
  }

  // Select folder in builder tree
  function selectBuilderFolder(path) {
    // Prevent selecting "home" as parent (no subpages allowed)
    if (path === 'home') {
      alert('Cannot create subpages under the home page. Please select a different folder.');
      return;
    }

    selectedBasePath = path;
    document.getElementById('base-path').value = path || '';

    // Update display
    const displayEl = document.getElementById('base-path-display');
    if (displayEl) {
      displayEl.textContent = path ? `/${path}` : '/ (root)';
    }

    // Update folder creation preview
    updateFolderPreview();

    // Show/hide clear selection button
    const clearBtn = document.getElementById('clear-selection-btn');
    if (clearBtn) {
      clearBtn.style.display = path ? 'inline' : 'none';
    }

    // Also auto-fill delete path input
    const deleteInput = document.getElementById('delete-path-input');
    if (deleteInput) {
      deleteInput.value = path || '';
    }

    // Update visual selection
    document.querySelectorAll('.builder-nav-item').forEach(item => {
      item.classList.remove('selected');
    });
    if (path) {
      const selectedElement = document.querySelector(`[data-builder-path="${path}"]`);
      if (selectedElement) {
        selectedElement.classList.add('selected');
      }
    }

    checkBuilderForNestedPaths();
  }

  // Clear folder selection (go back to root)
  function clearFolderSelection() {
    selectBuilderFolder('');
  }

  // Update the folder creation preview
  function updateFolderPreview() {
    const previewEl = document.getElementById('folder-preview-path');
    const firstPagePreviewEl = document.getElementById('folder-first-page-preview');
    const folderInputEl = document.getElementById('new-folder-path');
    const firstPageInputEl = document.getElementById('new-folder-first-page');
    if (!previewEl || !folderInputEl) return;

    const folderName = folderInputEl.value.trim();
    const firstPageName = firstPageInputEl ? firstPageInputEl.value.trim() : '';
    let fullFolderPath;

    if (selectedBasePath && folderName) {
      fullFolderPath = `/${selectedBasePath}/${folderName}`;
    } else if (folderName) {
      fullFolderPath = `/${folderName}`;
    } else if (selectedBasePath) {
      fullFolderPath = `/${selectedBasePath}/[folder-name]`;
    } else {
      fullFolderPath = '/[folder-name]';
    }

    previewEl.textContent = fullFolderPath;

    if (firstPagePreviewEl) {
      const base = fullFolderPath.replace('/[folder-name]', '');
      if (firstPageName && folderName) {
        firstPagePreviewEl.textContent = `${fullFolderPath}/${firstPageName}`;
      } else if (folderName) {
        firstPagePreviewEl.textContent = `${fullFolderPath}/[first-page-name]`;
      } else {
        firstPagePreviewEl.textContent = '/[first-page-name]';
      }
    }
  }

  // Build builder tree HTML
  function buildBuilderTreeHTML(nodes) {
    if (!nodes || nodes.length === 0) return '';

    let html = '<ul class="builder-nav-tree">';

    nodes.forEach(node => {
      const hasChildren = node.children && node.children.length > 0;
      const isExpanded = builderExpandedPaths.has(node.path);

      if (hasChildren) {
        const chevron = isExpanded ? '▼' : '▶';

        html += `
          <li class="builder-nav-folder ${isExpanded ? 'expanded' : 'collapsed'}">
            <div class="builder-nav-item" data-builder-path="${node.path}">
              <span class="builder-chevron" data-builder-toggle="${node.path}">${chevron}</span>
              <span class="builder-folder-name" data-builder-select="${node.path}">
                📁 ${node.title}
              </span>
            </div>
            ${isExpanded ? buildBuilderTreeHTML(node.children) : ''}
          </li>
        `;
      } else {
        html += `
          <li class="builder-nav-page">
            <div class="builder-nav-item" data-builder-path="${node.path}">
              <span class="builder-page-name" data-builder-select="${node.path}">📄 ${node.title}</span>
            </div>
          </li>
        `;
      }
    });

    html += '</ul>';
    return html;
  }

  // Render builder navigation tree
  function renderBuilderNavigationTree() {
    const container = document.getElementById('newpage-nav-tree');
    if (!container || !builderNavData) return;

    const html = buildBuilderTreeHTML(builderNavData);
    container.innerHTML = html;

    // Re-apply visual selection - innerHTML wipe removes the class
    if (selectedBasePath) {
      const selectedEl = container.querySelector(`[data-builder-path="${selectedBasePath}"]`);
      if (selectedEl) selectedEl.classList.add('selected');
    }

    // Add event listeners
    container.querySelectorAll('[data-builder-toggle]').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleBuilderFolder(el.dataset.builderToggle);
      });
    });

    container.querySelectorAll('[data-builder-select]').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        selectBuilderFolder(el.dataset.builderSelect);
      });
    });
  }

  // Check for nested paths and auto-check parent creation
  function checkBuilderForNestedPaths() {
    const inputs = document.querySelectorAll('.page-path');
    let hasNestedPaths = false;

    inputs.forEach(input => {
      if (input.value.includes('/')) {
        hasNestedPaths = true;
      }
    });

    // ALWAYS force the checkbox to be checked and hidden
    const checkbox = document.getElementById('create-parent-md');
    const wrapper = document.getElementById('create-parent-wrapper');
    
    checkbox.checked = true;
    wrapper.style.display = 'none'; // Hide the checkbox entirely
  }

  // Show builder modal
  function showBuilderModal() {
    const overlay = document.getElementById('wiki-newpage-modal-overlay');
    overlay.classList.add('visible');

    // Auto-select the current page's parent folder so the user lands in the
    // right place immediately. Root-level pages (no slash) default to root.
    const pathname = window.location.pathname;
    const pathMatch = pathname.match(/^\/[a-z]{2}\/(.*)/);
    const currentPath = pathMatch ? pathMatch[1] : pathname.replace(/^\//, '');
    // Use the current page itself as the base — it may already be a folder.
    // "Clear (use root)" is shown so the user can escape easily.
    const autoPath = (currentPath && currentPath !== 'home') ? currentPath : '';

    console.log('[Wiki Builder] currentPath:', currentPath, '→ autoPath:', autoPath);

    selectedBasePath = autoPath;
    document.getElementById('base-path').value = autoPath;

    // Pre-expand the current page and all its ancestors so the selection is
    // visible in the tree once the nav data arrives.
    builderExpandedPaths = new Set();
    if (autoPath) {
      const parts = autoPath.split('/');
      for (let i = 1; i <= parts.length; i++) {
        builderExpandedPaths.add(parts.slice(0, i).join('/'));
      }
    }

    // Update the "Working in:" display
    const displayEl = document.getElementById('base-path-display');
    if (displayEl) {
      displayEl.textContent = autoPath ? `/${autoPath}` : '/ (root)';
    }

    // Show "Clear (use root)" immediately when a path was auto-selected
    const clearBtn = document.getElementById('clear-selection-btn');
    if (clearBtn) {
      clearBtn.style.display = autoPath ? 'inline' : 'none';
    }

    // Clear page entries except first one
    const entriesContainer = document.getElementById('page-entries');
    entriesContainer.innerHTML = `
      <div class="page-entry">
        <input type="text" class="page-path" placeholder="page-name or folder/page-name" />
        <button class="remove-page" type="button">−</button>
      </div>
    `;

    // Hide and reset folder creation UI
    hideNewFolderInput();

    // Reset and hide checkbox (it's always forced to true anyway)
    document.getElementById('create-parent-md').checked = true;
    document.getElementById('create-parent-wrapper').style.display = 'none';

    // Clear delete input
    const deleteInput = document.getElementById('delete-path-input');
    if (deleteInput) {
      deleteInput.value = '';
    }

    // Clear status
    const status = document.getElementById('newpage-status-message');
    status.className = 'status-message';
    status.textContent = '';

    // Fetch fresh navigation data
    fetchBuilderNavigationTree();
  }

  // Hide builder modal
  function hideBuilderModal() {
    document.getElementById('wiki-newpage-modal-overlay').classList.remove('visible');
  }

  // Add another page entry
  function addBuilderPageEntry() {
    const entriesContainer = document.getElementById('page-entries');
    const newEntry = document.createElement('div');
    newEntry.className = 'page-entry';
    newEntry.innerHTML = `
      <input type="text" class="page-path" placeholder="page-name or folder/page-name" />
      <button class="remove-page" type="button">−</button>
    `;
    entriesContainer.appendChild(newEntry);
    checkBuilderForNestedPaths();
  }

  // Show new folder input
  function showNewFolderInput() {
    document.getElementById('new-folder-input-wrapper').style.display = 'block';
    document.getElementById('new-folder-btn').style.display = 'none';
    document.getElementById('new-folder-path').value = '';
    document.getElementById('new-folder-first-page').value = '';
    document.getElementById('confirm-folder-btn').disabled = true;
    document.getElementById('new-folder-path').focus();
    updateFolderPreview();
    hideFolderValidationMessage();
  }

  // Hide new folder input
  function hideNewFolderInput() {
    document.getElementById('new-folder-input-wrapper').style.display = 'none';
    document.getElementById('new-folder-btn').style.display = 'inline-block';
    document.getElementById('new-folder-path').value = '';
    document.getElementById('new-folder-first-page').value = '';
    hideFolderValidationMessage();
  }

  // Show folder validation message
  function showFolderValidationMessage(message, isError = true) {
    const msgElement = document.getElementById('folder-validation-message');
    msgElement.textContent = message;
    msgElement.style.display = 'block';
    msgElement.style.padding = '8px';
    msgElement.style.marginTop = '8px';
    msgElement.style.borderRadius = '4px';
    msgElement.style.fontSize = '13px';
    
    if (isError) {
      msgElement.style.background = '#f8d7da';
      msgElement.style.color = '#721c24';
      msgElement.style.border = '1px solid #f5c6cb';
    } else {
      msgElement.style.background = '#d4edda';
      msgElement.style.color = '#155724';
      msgElement.style.border = '1px solid #c3e6cb';
    }
  }

  // Hide folder validation message
  function hideFolderValidationMessage() {
    const msgElement = document.getElementById('folder-validation-message');
    msgElement.style.display = 'none';
    msgElement.textContent = '';
  }

  // Validate folder path input
  function validateFolderPath(path) {
    if (!path || path.trim() === '') {
      return { valid: false, message: 'Folder path cannot be empty' };
    }

    // Check for invalid characters
    if (!/^[a-z0-9\-\/]+$/.test(path)) {
      return { valid: false, message: 'Only lowercase letters, numbers, hyphens, and slashes allowed' };
    }

    // Check for consecutive slashes
    if (/\/\//.test(path)) {
      return { valid: false, message: 'Cannot have consecutive slashes' };
    }

    // Check for leading/trailing slashes
    if (path.startsWith('/') || path.endsWith('/')) {
      return { valid: false, message: 'Cannot start or end with a slash' };
    }

    return { valid: true };
  }

  // Shared helper: re-evaluate whether the confirm button should be enabled.
  // Both the folder name and the first-page name must be valid before enabling.
  function updateConfirmFolderBtn() {
    const confirmBtn = document.getElementById('confirm-folder-btn');
    const folderVal = sanitizeBuilderPath(document.getElementById('new-folder-path').value, true);
    const firstPageVal = sanitizeBuilderPath(document.getElementById('new-folder-first-page').value, true);

    const folderValid = validateFolderPath(folderVal).valid;
    const firstPageValid = firstPageVal.length > 0 && validateFolderPath(firstPageVal).valid;

    confirmBtn.disabled = !(folderValid && firstPageValid);
  }

  // Handle folder path input - auto-convert to valid format
  function handleFolderPathInput(e) {
    const input = e.target;
    const cursorPos = input.selectionStart;
    const originalLength = input.value.length;

    // Auto-convert using shared function (trimEnds=false to allow trailing hyphen while typing)
    let converted = sanitizeBuilderPath(input.value, false);

    // Update input if changed
    if (input.value !== converted) {
      input.value = converted;
      // Adjust cursor position
      const newCursorPos = Math.max(0, cursorPos - (originalLength - converted.length));
      input.setSelectionRange(newCursorPos, newCursorPos);
    }

    // Update path preview
    updateFolderPreview();

    if (!converted) {
      hideFolderValidationMessage();
      updateConfirmFolderBtn();
      return;
    }

    // Validate with trimmed version (what will actually be created)
    const trimmedPath = sanitizeBuilderPath(converted, true);
    const validation = validateFolderPath(trimmedPath);

    if (!validation.valid) {
      showFolderValidationMessage(validation.message, true);
    } else {
      hideFolderValidationMessage();
    }
    updateConfirmFolderBtn();
  }

  // Handle first-page input - auto-convert and update preview/button
  function handleFirstPageInput(e) {
    const input = e.target;
    const cursorPos = input.selectionStart;
    const originalLength = input.value.length;

    let converted = sanitizeBuilderPath(input.value, false);

    if (input.value !== converted) {
      input.value = converted;
      const newCursorPos = Math.max(0, cursorPos - (originalLength - converted.length));
      input.setSelectionRange(newCursorPos, newCursorPos);
    }

    updateFolderPreview();
    updateConfirmFolderBtn();
  }

  // Create new folder
  async function createNewFolder() {
    const pathInput = document.getElementById('new-folder-path');
    const firstPageInput = document.getElementById('new-folder-first-page');
    const confirmBtn = document.getElementById('confirm-folder-btn');
    // Sanitize and trim the paths for submission
    const path = sanitizeBuilderPath(pathInput.value, true);
    const firstPage = sanitizeBuilderPath(firstPageInput.value, true);

    const folderValidation = validateFolderPath(path);
    if (!folderValidation.valid) {
      showFolderValidationMessage(folderValidation.message, true);
      return;
    }

    if (!firstPage) {
      showFolderValidationMessage('First page name is required', true);
      return;
    }

    const firstPageValidation = validateFolderPath(firstPage);
    if (!firstPageValidation.valid) {
      showFolderValidationMessage(`First page: ${firstPageValidation.message}`, true);
      return;
    }

    // Build full path
    const fullPath = selectedBasePath ? `${selectedBasePath}/${path}` : path;

    // Show loading state
    confirmBtn.disabled = true;
    confirmBtn.textContent = '...';
    showFolderValidationMessage('Creating folder...', false);

    try {
      // Create the folder landing page and the user-specified first child page.
      // Wiki.js requires at least one child page for the parent to appear as a folder.
      const folderName = path.split('/').pop();
      const folderTitle = formatBuilderFolderName(folderName);
      const firstPageTitle = formatBuilderFolderName(firstPage.split('/').pop());

      const response = await fetch(`${API_URL}/api/pages/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pages: [
            { path: fullPath, title: folderTitle, isParent: true },
            { path: `${fullPath}/${firstPage}`, title: firstPageTitle, isParent: false }
          ]
        })
      });

      const result = await response.json();

      if (result.success) {
        showFolderValidationMessage(`✓ Folder "${folderName}" created!`, false);
        createdFolders.add(fullPath);

        // Refresh navigation tree
        await fetchBuilderNavigationTree();

        // Auto-select the new folder and expand it
        selectBuilderFolder(fullPath);
        builderExpandedPaths.add(fullPath);
        renderBuilderNavigationTree();

        // Hide input after short delay
        setTimeout(() => {
          hideNewFolderInput();
          confirmBtn.textContent = '✓';
        }, 1000);
      } else {
        showFolderValidationMessage(`Error: ${result.error}`, true);
        confirmBtn.disabled = false;
        confirmBtn.textContent = '✓';
      }
    } catch (error) {
      showFolderValidationMessage(`Failed to create folder: ${error.message}`, true);
    }
  }

  // Sanitize path: lowercase, replace spaces/underscores with hyphens, remove invalid chars
  // trimEnds=false for live input (keep trailing hyphen while typing), true for final submission
  function sanitizeBuilderPath(path, trimEnds = true) {
    let result = path
      .toLowerCase()
      .replace(/[\s_]+/g, '-')        // spaces and underscores to hyphens
      .replace(/[^a-z0-9\-\/]/g, '')  // remove invalid chars (keep letters, numbers, hyphens, slashes)
      .replace(/-+/g, '-')            // collapse multiple hyphens
      .replace(/\/+/g, '/');          // collapse multiple slashes

    if (trimEnds) {
      result = result.replace(/^[-\/]+|[-\/]+$/g, ''); // trim leading/trailing hyphens and slashes
    } else {
      result = result.replace(/^[-\/]+/, ''); // only trim leading (allow trailing while typing)
    }

    return result;
  }

  // Handle page path input - auto-convert to valid format
  function handlePagePathInput(e) {
    const input = e.target;
    const cursorPos = input.selectionStart;
    const originalLength = input.value.length;

    // Auto-convert: lowercase, spaces to dashes, remove invalid chars
    // Don't trim trailing hyphens while typing (trimEnds=false)
    let converted = sanitizeBuilderPath(input.value, false);

    // Update input if changed
    if (input.value !== converted) {
      input.value = converted;
      // Adjust cursor position
      const newCursorPos = Math.max(0, cursorPos - (originalLength - converted.length));
      input.setSelectionRange(newCursorPos, newCursorPos);
    }

    checkBuilderForNestedPaths();
  }

  // Create pages
  async function createBuilderPages() {
    const basePath = document.getElementById('base-path').value;
    const pageInputs = document.querySelectorAll('.page-path');
    const statusEl = document.getElementById('newpage-status-message');

    // Collect and sanitize page paths
    const pagePaths = Array.from(pageInputs)
      .map(input => sanitizeBuilderPath(input.value))
      .filter(path => path.length > 0);

    if (pagePaths.length === 0) {
      statusEl.className = 'status-message error visible';
      statusEl.textContent = 'Please enter at least one page path';
      return;
    }

    // Show loading
    statusEl.className = 'status-message loading visible';
    statusEl.textContent = 'Creating pages...';

    try {
      // Build full paths - if basePath is set, prepend it
      const fullPaths = pagePaths.map(path => {
        if (!basePath || basePath === '') {
          return path;  // Root level
        }
        return `${basePath}/${path}`;  // Inside selected folder
      });

      // Extract all unique parent folders that need .md files
      const parentFolders = new Set();
      fullPaths.forEach(fullPath => {
        const parts = fullPath.split('/');
        for (let i = 1; i < parts.length; i++) {
          parentFolders.add(parts.slice(0, i).join('/'));
        }
      });

      // Build pages array for API - parents first, then actual pages
      const pagesToCreate = [];
      const seen = new Set();

      // Add parent folders
      for (const folderPath of parentFolders) {
        if (createdFolders.has(folderPath) || seen.has(folderPath)) continue;
        seen.add(folderPath);
        const folderTitle = formatBuilderFolderName(folderPath.split('/').pop());
        pagesToCreate.push({ path: folderPath, title: folderTitle, isParent: true });
      }

      // Add actual pages
      for (const fullPath of fullPaths) {
        if (seen.has(fullPath)) continue;
        seen.add(fullPath);
        const pageTitle = formatBuilderFolderName(fullPath.split('/').pop());
        pagesToCreate.push({ path: fullPath, title: pageTitle, isParent: false });
      }

      // Send all pages in one request
      const response = await fetch(`${API_URL}/api/pages/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pages: pagesToCreate })
      });

      const result = await response.json();

      if (result.success) {
        const createdCount = result.pages ? result.pages.length : pagesToCreate.length;
        const errorCount = result.errors ? result.errors.length : 0;

        // Track created folders
        pagesToCreate.filter(p => p.isParent).forEach(p => createdFolders.add(p.path));

        if (errorCount > 0) {
          statusEl.className = 'status-message success visible';
          statusEl.textContent = `Created ${createdCount} page(s), ${errorCount} skipped/failed`;
        } else {
          statusEl.className = 'status-message success visible';
          statusEl.textContent = `Created ${createdCount} page(s) successfully!`;
        }

        // Close modal and navigate to the first created page
        setTimeout(() => {
          hideBuilderModal();
          window.location.href = `${window.location.origin}/en/${fullPaths[0]}`;
        }, 1500);
      } else {
        statusEl.className = 'status-message error visible';
        statusEl.textContent = `Failed: ${result.error}`;
      }

    } catch (error) {
      statusEl.className = 'status-message error visible';
      statusEl.textContent = `Error: ${error.message}`;
    }
  }

  // Create builder modal
  function createBuilderModal() {
    const container = document.createElement('div');
    container.innerHTML = `
      <style>
        #wiki-newpage-modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0,0,0,0.5);
          z-index: 10000;
          display: none;
          align-items: center;
          justify-content: center;
        }

        #wiki-newpage-modal-overlay.visible {
          display: flex;
        }

        #wiki-newpage-modal {
          width: 90%;
          max-width: 600px;
          max-height: 90vh;
          background: #ffffff;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.3);
          overflow: hidden;
          display: flex;
          flex-direction: column;
        }

        .newpage-modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px 20px;
          background: #4CAF50;
          color: white;
        }

        .newpage-modal-header h3 {
          margin: 0;
          font-size: 18px;
          font-weight: 600;
        }

        #newpage-close-btn {
          background: none;
          border: none;
          color: white;
          font-size: 28px;
          cursor: pointer;
          padding: 0;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 4px;
          transition: background 0.2s;
        }

        #newpage-close-btn:hover {
          background: rgba(255,255,255,0.2);
        }

        .newpage-modal-body {
          padding: 20px;
          overflow-y: auto;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          font-size: 14px;
        }

        .section-label {
          font-weight: 600;
          margin-bottom: 8px;
          color: #333;
        }

        #newpage-nav-tree {
          max-height: 200px;
          overflow-y: auto;
          border: 1px solid #ddd;
          border-radius: 6px;
          padding: 8px;
          background: #fafafa;
          margin-bottom: 16px;
        }

        .builder-nav-tree {
          list-style: none;
          padding: 0;
          margin: 0;
        }

        .builder-nav-tree li {
          margin: 0;
          padding: 0;
        }

        .builder-nav-item {
          display: flex;
          align-items: center;
          padding: 4px 8px;
          cursor: pointer;
          border-radius: 4px;
          transition: background 0.2s;
        }

        .builder-nav-item:hover {
          background: rgba(76, 175, 80, 0.1);
        }

        .builder-nav-item.selected {
          background: rgba(76, 175, 80, 0.3);
          font-weight: 600;
        }

        .builder-chevron {
          min-width: 16px;
          font-size: 10px;
          margin-right: 4px;
          color: #666;
        }

        .builder-folder-name,
        .builder-page-name {
          font-size: 14px;
          color: #333;
        }

        .builder-nav-folder.collapsed > ul {
          display: none;
        }

        .builder-nav-folder.expanded > ul {
          display: block;
          margin-left: 20px;
        }

        .path-display {
          margin-bottom: 16px;
        }

        .path-display label {
          display: block;
          font-size: 13px;
          color: #666;
          margin-bottom: 4px;
        }

        .path-display input {
          width: 100%;
          padding: 10px;
          border: 1px solid #ddd;
          border-radius: 6px;
          font-size: 14px;
          background: #f5f5f5;
          box-sizing: border-box;
        }

        #page-entries {
          margin-bottom: 12px;
        }

        .page-entry {
          display: flex;
          gap: 8px;
          margin-bottom: 8px;
        }

        .page-entry input {
          flex: 1;
          padding: 10px;
          border: 1px solid #ddd;
          border-radius: 6px;
          font-size: 14px;
          box-sizing: border-box;
        }

        .page-entry button {
          width: 40px;
          height: 40px;
          border: 1px solid #ddd;
          border-radius: 6px;
          background: #fff;
          cursor: pointer;
          font-size: 18px;
          transition: all 0.2s;
        }

        .page-entry button:hover {
          background: #f44336;
          color: white;
          border-color: #f44336;
        }

        #add-page-btn,
        #new-folder-btn,
        #confirm-folder-btn,
        #cancel-folder-btn {
          padding: 8px 16px;
          border: 1px solid #ddd;
          border-radius: 6px;
          background: #fff;
          cursor: pointer;
          font-size: 14px;
          transition: all 0.2s;
        }

        #add-page-btn:hover,
        #new-folder-btn:hover {
          background: #f5f5f5;
          border-color: #4CAF50;
        }

        #confirm-folder-btn {
          background: #4CAF50;
          color: white;
          border-color: #4CAF50;
        }

        #confirm-folder-btn:hover:not(:disabled) {
          background: #45a049;
        }

        #confirm-folder-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        #cancel-folder-btn {
          background: #f44336;
          color: white;
          border-color: #f44336;
        }

        #cancel-folder-btn:hover {
          background: #da190b;
        }

        #new-folder-path,
        #new-folder-first-page {
          padding: 8px;
          border: 1px solid #ddd;
          border-radius: 6px;
          font-size: 14px;
        }

        #add-page-btn {
          display: block;
          margin-bottom: 16px;
        }

        #create-parent-wrapper {
          display: flex;
          align-items: center;
          margin-bottom: 16px;
          color: #666;
          cursor: pointer;
        }

        #create-parent-wrapper input {
          margin-right: 8px;
          cursor: pointer;
        }

        .modal-actions {
          display: flex;
          gap: 10px;
          margin-top: 16px;
        }

        .modal-actions button {
          flex: 1;
          padding: 12px;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-size: 14px;
          font-weight: 500;
        }

        #create-pages-btn {
          background: #4CAF50;
          color: white;
        }

        #create-pages-btn:hover {
          background: #45a049;
        }

        #cancel-btn {
          background: #ddd;
          color: #333;
        }

        #cancel-btn:hover {
          background: #ccc;
        }

        .status-message {
          padding: 10px;
          margin-top: 12px;
          border-radius: 6px;
          font-size: 13px;
          display: none;
        }

        .status-message.visible {
          display: block;
        }

        .status-message.success {
          background: #d4edda;
          color: #155724;
          border: 1px solid #c3e6cb;
        }

        .status-message.error {
          background: #f8d7da;
          color: #721c24;
          border: 1px solid #f5c6cb;
        }

        .status-message.loading {
          background: #d1ecf1;
          color: #0c5460;
          border: 1px solid #bee5eb;
        }

        .delete-section {
          margin-top: 24px;
          padding-top: 16px;
          border-top: 2px solid #ddd;
        }

        .delete-section h4 {
          color: #d32f2f;
          margin: 0 0 12px 0;
          font-size: 16px;
        }

        .delete-controls {
          display: flex;
          gap: 8px;
          align-items: stretch;
        }

        #delete-path-input {
          flex: 1;
          padding: 10px;
          border: 1px solid #ddd;
          border-radius: 6px;
          font-size: 14px;
        }

        #delete-btn {
          padding: 10px 20px;
          background: #d32f2f;
          color: white;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-size: 14px;
          font-weight: 500;
          transition: background 0.2s;
        }

        #delete-btn:hover {
          background: #b71c1c;
        }

        .delete-options {
          margin-top: 8px;
          font-size: 13px;
        }

        .delete-options label {
          display: flex;
          align-items: center;
          color: #666;
          cursor: pointer;
          margin-bottom: 4px;
        }

        .delete-options input {
          margin-right: 8px;
        }
      </style>

      <div id="wiki-newpage-modal-overlay">
        <div id="wiki-newpage-modal">
          <div class="newpage-modal-header">
            <h3>📄 Create New Page(s)</h3>
            <button id="newpage-close-btn">&times;</button>
          </div>

          <div class="newpage-modal-body">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
              <div class="section-label" style="margin: 0;">Select location:</div>
              <span id="clear-selection-btn" style="font-size: 12px; color: #1976d2; cursor: pointer; display: none;">✕ Clear (use root)</span>
            </div>

            <div id="new-folder-controls" style="margin-bottom: 12px;">
              <button id="new-folder-btn" type="button">+ Create New Folder</button>

              <div id="new-folder-input-wrapper" style="display: none;">
                <div id="folder-path-preview" style="font-size: 12px; color: #666; margin-bottom: 6px; padding: 6px; background: #f5f5f5; border-radius: 4px;">
                  Folder: <strong id="folder-preview-path">/ (root level)</strong><br>
                  First page: <strong id="folder-first-page-preview">/[first-page-name]</strong>
                </div>
                <div style="display: flex; gap: 8px; margin-bottom: 6px;">
                  <input
                    type="text"
                    id="new-folder-path"
                    placeholder="folder-name"
                    style="flex: 1;"
                  />
                </div>
                <div style="display: flex; gap: 8px;">
                  <input
                    type="text"
                    id="new-folder-first-page"
                    placeholder="first-page-name (required)"
                    style="flex: 1;"
                  />
                  <button id="confirm-folder-btn" type="button" title="Create folder" disabled>✓</button>
                  <button id="cancel-folder-btn" type="button" title="Cancel">✕</button>
                </div>
                <div id="folder-validation-message" style="display: none;"></div>
              </div>
            </div>

            <div id="newpage-nav-tree"></div>

            <div class="path-display">
              <label>Working in: <span id="base-path-display" style="font-weight: 600;">/ (root)</span></label>
              <input type="hidden" id="base-path" value="" />
            </div>

            <div class="section-label">New Pages:</div>
            <div id="page-entries">
              <div class="page-entry">
                <input type="text" class="page-path" placeholder="page-name or folder/page-name" />
                <button class="remove-page" type="button">−</button>
              </div>
            </div>

            <button id="add-page-btn" type="button">+ Add Another Page</button>

            <label id="create-parent-wrapper" style="display: none;">
              <input type="checkbox" id="create-parent-md" checked />
              Create parent .md files for nested folders (always enabled)
            </label>

            <div class="modal-actions">
              <button id="create-pages-btn" type="button">Create Pages</button>
              <button id="cancel-btn" type="button">Cancel</button>
            </div>

            <div class="delete-section">
              <h4>📦 Remove Page/Folder</h4>
              <p style="font-size: 12px; color: #666; margin: 0 0 8px 0;">Select from tree above or type a path.</p>
              <div class="delete-controls">
                <input
                  type="text"
                  id="delete-path-input"
                  placeholder="Select from tree or type path"
                />
              </div>
              <div class="delete-options">
                <label>
                  <input type="checkbox" id="delete-recursive" checked />
                  Include all subpages (recursive)
                </label>
              </div>
              <div class="delete-buttons" style="display: flex; gap: 8px; margin-top: 10px;">
                <button id="archive-btn" type="button" style="flex: 1; padding: 10px; background: #ff9800; color: white; border: none; border-radius: 6px; cursor: pointer;">📦 Archive</button>
                <button id="delete-btn" type="button" style="flex: 1; padding: 10px; background: #d32f2f; color: white; border: none; border-radius: 6px; cursor: pointer;">🗑️ Delete Forever</button>
              </div>
              <p style="font-size: 11px; color: #999; margin: 8px 0 0 0;">Archive = hidden but restorable | Delete = permanent removal</p>
            </div>

            <div id="newpage-status-message" class="status-message"></div>
          </div>
        </div>
      </div>
    `;

    return container;
  }

  // Count children for a path in the nav data
  function countChildPages(path) {
    if (!builderNavData) return 0;

    let count = 0;
    function countInNodes(nodes) {
      for (const node of nodes) {
        if (node.path.startsWith(path + '/')) {
          count++;
        }
        if (node.children && node.children.length > 0) {
          countInNodes(node.children);
        }
      }
    }
    countInNodes(builderNavData);
    return count;
  }

  // Remove page or folder (archive or permanent delete)
  async function removePage(permanent = false) {
    const pathInput = document.getElementById('delete-path-input');
    const recursive = document.getElementById('delete-recursive').checked;
    const statusEl = document.getElementById('newpage-status-message');

    let deletePath = pathInput.value.trim();

    if (!deletePath) {
      statusEl.className = 'status-message error visible';
      statusEl.textContent = 'Please select a page/folder from the tree or enter a path';
      return;
    }

    // Count child pages
    const childCount = countChildPages(deletePath);

    // Build confirmation message with child count
    const action = permanent ? 'PERMANENTLY DELETE' : 'archive';
    const warning = permanent ? '⚠️ THIS CANNOT BE UNDONE!' : 'Admin can restore via SQL if needed.';

    let confirmMsg;
    if (recursive && childCount > 0) {
      confirmMsg = `${action.toUpperCase()} "${deletePath}" and ${childCount} subpage(s)?\n\n${warning}`;
    } else if (childCount > 0 && !recursive) {
      confirmMsg = `${action.toUpperCase()} "${deletePath}" only?\n\nNote: This has ${childCount} subpage(s) that will NOT be affected.\n\n${warning}`;
    } else {
      confirmMsg = `${action.toUpperCase()} "${deletePath}"?\n\n${warning}`;
    }

    if (!confirm(confirmMsg)) {
      return;
    }

    statusEl.className = 'status-message loading visible';
    statusEl.textContent = permanent ? 'Deleting permanently...' : 'Archiving...';

    try {
      const response = await fetch(`${API_URL}/api/pages/delete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          path: deletePath,
          recursive: recursive,
          permanent: permanent
        })
      });

      const result = await response.json();

      if (result.success) {
        const count = result.archived ? result.archived.length : (result.deleted ? result.deleted.length : 1);
        statusEl.className = 'status-message success visible';
        statusEl.textContent = permanent
          ? `Permanently deleted ${count} page(s)!`
          : `Archived ${count} page(s) successfully!`;

        // Clear input
        pathInput.value = '';

        // Refresh navigation tree
        await fetchBuilderNavigationTree();

        // Only navigate away if we just deleted/archived the page we're currently on
        // (or an ancestor of it). Otherwise keep the modal open so the user can continue.
        const curPathMatch = window.location.pathname.match(/^\/[a-z]{2}\/(.*)/);
        const currentPagePath = curPathMatch ? curPathMatch[1] : window.location.pathname.replace(/^\//, '');
        const deletedCurrentPage = currentPagePath === deletePath ||
                                   currentPagePath.startsWith(deletePath + '/');

        if (deletedCurrentPage) {
          const lastSlash = deletePath.lastIndexOf('/');
          const parentPath = lastSlash > 0 ? deletePath.substring(0, lastSlash) : '';
          setTimeout(() => {
            window.location.href = parentPath
              ? `${window.location.origin}/en/${parentPath}`
              : `${window.location.origin}/en/home`;
          }, 1500);
        }
      } else {
        statusEl.className = 'status-message error visible';
        statusEl.textContent = `Failed: ${result.error}`;
      }
    } catch (error) {
      statusEl.className = 'status-message error visible';
      statusEl.textContent = `Error: ${error.message}`;
    }
  }

  // Initialize
  async function initBuilder(retryCount = 0) {
    if (document.getElementById('wiki-newpage-btn')) return;

    const navDrawer = document.querySelector('.v-navigation-drawer');
    if (!navDrawer) {
      if (retryCount < 10) {
        setTimeout(() => initBuilder(retryCount + 1), 500);
      }
      return;
    }

    const modal = createBuilderModal();
    document.body.appendChild(modal);

    const newPageBtn = document.createElement('div');
    newPageBtn.id = 'wiki-newpage-btn';
    newPageBtn.style.cssText = 'padding: 12px 16px; cursor: pointer; background: rgba(255,255,255,0.1); margin: 8px; border-radius: 4px; display: flex; align-items: center; gap: 8px; color: white; font-size: 14px;';
    newPageBtn.innerHTML = `
      <i class="mdi mdi-file-plus" style="font-size: 20px;"></i>
      <span>New Page</span>
    `;

    newPageBtn.addEventListener('click', showBuilderModal);
    newPageBtn.addEventListener('mouseenter', () => {
      newPageBtn.style.background = 'rgba(255,255,255,0.15)';
    });
    newPageBtn.addEventListener('mouseleave', () => {
      newPageBtn.style.background = 'rgba(255,255,255,0.1)';
    });

    navDrawer.insertBefore(newPageBtn, navDrawer.firstChild);

    document.getElementById('newpage-close-btn').addEventListener('click', hideBuilderModal);
    document.getElementById('cancel-btn').addEventListener('click', hideBuilderModal);

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && document.getElementById('wiki-newpage-modal-overlay').classList.contains('visible')) {
        hideBuilderModal();
      }
    });

    document.getElementById('add-page-btn').addEventListener('click', addBuilderPageEntry);
    document.getElementById('create-pages-btn').addEventListener('click', createBuilderPages);
    document.getElementById('archive-btn').addEventListener('click', () => removePage(false));
    document.getElementById('delete-btn').addEventListener('click', () => removePage(true));

    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('remove-page')) {
        const entries = document.querySelectorAll('.page-entry');
        if (entries.length > 1) {
          e.target.closest('.page-entry').remove();
          checkBuilderForNestedPaths();
        }
      }
    });

    // Auto-convert page path inputs as user types
    document.getElementById('page-entries').addEventListener('input', (e) => {
      if (e.target.classList.contains('page-path')) {
        handlePagePathInput(e);
      }
    });

    // Clear selection button
    document.getElementById('clear-selection-btn').addEventListener('click', clearFolderSelection);

    document.getElementById('new-folder-btn').addEventListener('click', showNewFolderInput);
    document.getElementById('cancel-folder-btn').addEventListener('click', hideNewFolderInput);
    document.getElementById('confirm-folder-btn').addEventListener('click', createNewFolder);
    document.getElementById('new-folder-path').addEventListener('input', handleFolderPathInput);
    document.getElementById('new-folder-first-page').addEventListener('input', handleFirstPageInput);

    const folderInputKeydown = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        // Tab from folder-name to first-page on Enter
        if (e.target.id === 'new-folder-path') {
          document.getElementById('new-folder-first-page').focus();
        } else {
          const confirmBtn = document.getElementById('confirm-folder-btn');
          if (!confirmBtn.disabled) createNewFolder();
        }
      } else if (e.key === 'Escape') {
        e.preventDefault();
        hideNewFolderInput();
      }
    };

    document.getElementById('new-folder-path').addEventListener('keydown', folderInputKeydown);
    document.getElementById('new-folder-first-page').addEventListener('keydown', folderInputKeydown);

    await fetchBuilderNavigationTree();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initBuilder);
  } else {
    initBuilder();
  }
})();
