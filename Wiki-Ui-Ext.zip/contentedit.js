(() => {
  'use strict';

  console.log('[EAPW Wiki Extension] content-edit loaded');

  // ==============================
  // PASTE YOUR EDIT SCRIPTS HERE
  // ==============================
  //
  // - Auto Markdown Images
  // - Edit Page Actions (Alt+R / Alt+X)
  // - Editor DOM logic
  //
  // IMPORTANT:
  // - Remove all // ==UserScript== headers
  // - Remove @match, @run-at
  // - Keep keyboard shortcuts exactly as-is
  //

  console.log('[Wiki Upload] Tampermonkey script loaded!');

  // Configuration
  const API_URL = 'http://eapw-105:22001';

  // Get current Wiki.js page path
  function getCurrentPath() {
    return window.location.pathname;
  }

  // Get current username (try to extract from Wiki.js)
  function getCurrentUsername() {
    const userMenu = document.querySelector('.v-toolbar__title');
    if (userMenu) {
      const username = userMenu.textContent.trim();
      if (username) return username;
    }
    return 'user';
  }

  // Create the modal (button will be injected into sidebar separately)
  function createWidget() {
    const container = document.createElement('div');
    container.innerHTML = `
      <style>

        /* Modal overlay */
        #wiki-upload-modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0,0,0,0.5);
          z-index: 10000;
          display: none;
          align-items: center;
          justify-content: center;
        }

        #wiki-upload-modal-overlay.visible {
          display: flex;
        }

        /* Modal content */
        #wiki-image-upload-modal {
          width: 90%;
          max-width: 420px;
          max-height: 90vh;
          background: #ffffff;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.3);
          overflow: hidden;
          display: flex;
          flex-direction: column;
        }

        /* Modal header */
        #wiki-upload-modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px 16px;
          background: #4CAF50;
          color: white;
        }

        #wiki-upload-modal-header h3 {
          margin: 0;
          font-size: 16px;
          font-weight: 600;
        }

        #wiki-upload-close-btn {
          background: none;
          border: none;
          color: white;
          font-size: 24px;
          cursor: pointer;
          padding: 0;
          width: 28px;
          height: 28px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 4px;
          transition: background 0.2s;
        }

        #wiki-upload-close-btn:hover {
          background: rgba(255,255,255,0.2);
        }

        /* Modal body */
        #wiki-upload-modal-body {
          padding: 16px;
          overflow-y: auto;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          font-size: 14px;
        }

        /* Top row: prefix + size options */
        .upload-top-row {
          display: flex;
          gap: 12px;
          margin-bottom: 12px;
          align-items: flex-start;
        }

        .prefix-group {
          flex: 1;
        }

        .prefix-group label {
          font-size: 11px;
          color: #666;
          display: block;
          margin-bottom: 4px;
        }

        .prefix-input {
          width: 100%;
          padding: 8px;
          border: 1px solid #ddd;
          border-radius: 4px;
          font-size: 13px;
          box-sizing: border-box;
        }

        .size-group {
          flex: 1.2;
        }

        .size-group label {
          font-size: 11px;
          color: #666;
          display: block;
          margin-bottom: 4px;
        }

        .size-options {
          display: flex;
          gap: 4px;
        }

        .size-option {
          flex: 1;
          padding: 6px 2px;
          border: 1px solid #ddd;
          border-radius: 4px;
          background: #fff;
          cursor: pointer;
          font-size: 11px;
          text-align: center;
          transition: all 0.2s;
        }

        .size-option:hover {
          border-color: #4CAF50;
        }

        .size-option.selected {
          background: #4CAF50;
          color: white;
          border-color: #4CAF50;
        }

        /* Primary paste area */
        .paste-area {
          width: 100%;
          min-height: 70px;
          padding: 16px;
          border: 2px solid #4CAF50;
          border-radius: 8px;
          background: #f0f8f0;
          font-size: 14px;
          color: #2e7d32;
          text-align: center;
          cursor: text;
          box-sizing: border-box;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
          margin-bottom: 10px;
          font-weight: 500;
        }

        .paste-area:focus {
          outline: none;
          border-color: #2e7d32;
          background: #e8f5e9;
          box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.2);
        }

        .paste-area.uploading {
          background: #fff3e0;
          border-color: #ff9800;
          color: #e65100;
        }

        /* Secondary options row */
        .secondary-options {
          display: flex;
          gap: 8px;
          margin-bottom: 10px;
        }

        .drop-zone {
          flex: 1;
          border: 1px dashed #ccc;
          border-radius: 4px;
          padding: 10px 8px;
          text-align: center;
          background: #fafafa;
          cursor: pointer;
          transition: all 0.2s;
          font-size: 11px;
          color: #888;
        }

        .drop-zone:hover,
        .drop-zone.drag-over {
          border-color: #4CAF50;
          background: #f0f8f0;
          color: #4CAF50;
        }

        .upload-button {
          flex: 1;
          padding: 10px 8px;
          border: 1px solid #ddd;
          border-radius: 4px;
          background: #fff;
          cursor: pointer;
          font-size: 11px;
          color: #666;
          transition: all 0.2s;
        }

        .upload-button:hover {
          background: #f5f5f5;
          border-color: #4CAF50;
          color: #4CAF50;
        }

        .status-message {
          padding: 8px 10px;
          margin-bottom: 10px;
          border-radius: 4px;
          font-size: 12px;
          display: none;
        }

        .status-message.visible {
          display: block;
        }

        .status-message.success {
          background: #d4edda;
          color: #155724;
          border: 1px solid #c3e6cb;
        }

        .status-message.error {
          background: #f8d7da;
          color: #721c24;
          border: 1px solid #f5c6cb;
        }

        .status-message.loading {
          background: #d1ecf1;
          color: #0c5460;
          border: 1px solid #bee5eb;
        }

        /* Result area - prominent when visible */
        .result-area {
          padding: 12px;
          background: #e3f2fd;
          border-radius: 6px;
          border: 2px solid #2196F3;
          display: none;
        }

        .result-area.visible {
          display: block;
        }

        .result-label {
          font-size: 11px;
          color: #1565c0;
          margin-bottom: 6px;
          font-weight: 600;
        }

        .result-markdown {
          background: #fff;
          padding: 10px;
          border: 1px solid #90caf9;
          border-radius: 4px;
          font-family: 'Courier New', monospace;
          font-size: 12px;
          word-break: break-all;
          margin-bottom: 8px;
          max-height: 80px;
          overflow-y: auto;
          cursor: text;
          user-select: all;
        }

        .result-buttons {
          display: flex;
          gap: 8px;
        }

        .copy-btn {
          flex: 1;
          padding: 10px;
          background: #2196F3;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 13px;
          font-weight: 500;
          transition: background 0.2s;
        }

        .copy-btn:hover {
          background: #1976D2;
        }

        .copy-btn.copied {
          background: #4CAF50;
        }

        .insert-btn {
          flex: 1;
          padding: 10px;
          background: #4CAF50;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 13px;
          font-weight: 500;
          transition: background 0.2s;
        }

        .insert-btn:hover {
          background: #388E3C;
        }

        .file-browser {
          margin-top: 10px;
          max-height: 150px;
          overflow-y: auto;
          border: 1px solid #ddd;
          border-radius: 4px;
          background: #fff;
          display: none;
        }

        .file-browser.visible {
          display: block;
        }

        .file-item {
          padding: 8px 10px;
          border-bottom: 1px solid #f0f0f0;
          cursor: pointer;
          font-size: 12px;
          transition: background 0.2s;
        }

        .file-item:hover {
          background: #f5f5f5;
        }

        .file-item:last-child {
          border-bottom: none;
        }

        .file-name {
          font-weight: 500;
          color: #333;
          word-break: break-all;
        }

        .file-date {
          font-size: 10px;
          color: #999;
          margin-top: 2px;
        }

        .hidden {
          display: none;
        }
      </style>

      <!-- Modal overlay -->
      <div id="wiki-upload-modal-overlay">
        <div id="wiki-image-upload-modal">
          <div id="wiki-upload-modal-header">
            <h3>📎 Upload Image</h3>
            <button id="wiki-upload-close-btn">&times;</button>
          </div>

          <div id="wiki-upload-modal-body">
            <div class="upload-top-row">
              <div class="prefix-group">
                <label>Filename Prefix</label>
                <input type="text" class="prefix-input" id="upload-prefix" placeholder="prefix" />
              </div>
              <div class="size-group">
                <label>Image Width</label>
                <div class="size-options">
                  <div class="size-option selected" data-width="">Auto</div>
                  <div class="size-option" data-width="400">S</div>
                  <div class="size-option" data-width="600">M</div>
                  <div class="size-option" data-width="800">L</div>
                </div>
              </div>
            </div>

            <div class="paste-area" id="paste-area" contenteditable="true" tabindex="0">📋 Click here + Ctrl+V to paste</div>

            <div class="secondary-options">
              <div class="drop-zone" id="drop-zone">📁 Drop file or click</div>
              <button class="upload-button" id="browse-btn">📂 Browse existing</button>
            </div>

            <input type="file" id="file-input" accept="image/*" class="hidden" />

            <div class="status-message" id="status-message"></div>

            <div class="result-area" id="result-area">
              <div class="result-label">✓ READY TO USE:</div>
              <div class="result-markdown" id="result-markdown"></div>
              <div class="result-buttons">
                <button class="copy-btn" id="copy-btn">📋 Copy</button>
                <button class="insert-btn" id="insert-btn">⏎ Insert at Cursor</button>
              </div>
            </div>

            <div class="file-browser" id="file-browser"></div>
          </div>
        </div>
      </div>
    `;

    return container;
  }

  // Show/hide modal
  function showModal() {
    document.getElementById('wiki-upload-modal-overlay').classList.add('visible');
  }

  function hideModal() {
    document.getElementById('wiki-upload-modal-overlay').classList.remove('visible');
  }

  // Show status message
  function showStatus(message, type = 'loading') {
    const statusEl = document.getElementById('status-message');
    if (statusEl) {
      statusEl.textContent = message;
      statusEl.className = 'status-message visible ' + type;

      if (type === 'success' || type === 'error') {
        setTimeout(() => {
          statusEl.classList.remove('visible');
        }, 3000);
      }
    }
  }

  // Get selected image width
  function getSelectedWidth() {
    const selected = document.querySelector('.size-option.selected');
    return selected ? selected.dataset.width : '';
  }

  // Format as img tag - centered at specified width (default 800)
  function formatMarkdown(url, width) {
    const w = width || '800';
    return `<img src="${url}" width="${w}" style="display: block; margin: 0 auto;" />`;
  }

  // Show result and auto-select
  function showResult(markdown) {
    const resultArea = document.getElementById('result-area');
    const resultMarkdown = document.getElementById('result-markdown');

    if (resultArea && resultMarkdown) {
      resultMarkdown.textContent = markdown;
      resultArea.classList.add('visible');

      // Auto-select the markdown text for easy copying
      setTimeout(() => {
        const range = document.createRange();
        range.selectNodeContents(resultMarkdown);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
      }, 100);
    }
  }

  // Copy to clipboard with proper async handling
  async function copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (err) {
      // Fallback for older browsers or security restrictions
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-9999px';
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        document.body.removeChild(textArea);
        return true;
      } catch (e) {
        document.body.removeChild(textArea);
        return false;
      }
    }
  }

  // Insert markdown at cursor in CodeMirror editor
  function insertAtCursor(markdown) {
    const editor = document.querySelector('.CodeMirror');
    if (editor && editor.CodeMirror) {
      editor.CodeMirror.replaceSelection(markdown);
      editor.CodeMirror.focus();
      return true;
    }
    return false;
  }

  // Upload image to backend (new ID-based API)
  async function uploadImage(imageFile, prefix, widthOverride = null) {
    const pasteArea = document.getElementById('paste-area');
    if (pasteArea) {
      pasteArea.classList.add('uploading');
      pasteArea.textContent = '⏳ Uploading...';
    }

    const formData = new FormData();
    formData.append('image', imageFile);
    formData.append('currentPath', getCurrentPath());
    formData.append('prefix', prefix || getCurrentUsername());
    formData.append('username', getCurrentUsername());

    try {
      showStatus('Uploading...', 'loading');

      // Use new ID-based endpoint
      const response = await fetch(`${API_URL}/api/images/upload`, {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (pasteArea) {
        pasteArea.classList.remove('uploading');
        pasteArea.textContent = '📋 Click here + Ctrl+V to paste';
      }

      if (data.success) {
        showStatus('Upload successful!', 'success');

        // Apply selected width to markdown (or override for quick paste)
        const width = widthOverride !== null ? widthOverride : getSelectedWidth();
        const markdown = formatMarkdown(data.fullUrl, width);
        showResult(markdown);

        return { ...data, markdown };
      } else {
        showStatus('Error: ' + data.error, 'error');
        return null;
      }
    } catch (error) {
      if (pasteArea) {
        pasteArea.classList.remove('uploading');
        pasteArea.textContent = '📋 Click here + Ctrl+V to paste';
      }
      showStatus('Upload failed: ' + error.message, 'error');
      return null;
    }
  }

  // Quick upload from clipboard (Alt+M shortcut) - no modal, direct insert
  async function quickUploadFromClipboard() {
    showQuickNotification('📋 Reading clipboard...', 'loading');

    try {
      // Try the modern clipboard API first
      if (navigator.clipboard && navigator.clipboard.read) {
        const clipboardItems = await navigator.clipboard.read();

        for (const item of clipboardItems) {
          for (const type of item.types) {
            if (type.startsWith('image/')) {
              const blob = await item.getType(type);
              await processAndInsertImage(blob);
              return;
            }
          }
        }
        showQuickNotification('No image in clipboard', 'error');
        return;
      }
    } catch (error) {
      console.log('[Wiki Upload] Clipboard read API failed:', error.message);
    }

    // Fallback: Create a temporary paste target to capture clipboard
    try {
      await fallbackPasteCapture();
    } catch (error) {
      showQuickNotification('Clipboard access denied - use modal', 'error');
    }
  }

  // Process blob and insert at cursor
  async function processAndInsertImage(blob) {
    showQuickNotification('⏳ Uploading...', 'loading');

    const result = await uploadImageDirect(blob, getCurrentUsername(), '800');

    if (result && result.markdown) {
      // Insert via page context helper
      const success = insertIntoEditor(result.markdown);
      if (success) {
        showQuickNotification('✓ Image inserted!', 'success');
      } else {
        // Fallback: copy to clipboard
        await copyToClipboard(result.markdown);
        showQuickNotification('✓ Copied to clipboard!', 'success');
      }
    } else {
      showQuickNotification('Upload failed', 'error');
    }
  }

  // Direct upload without updating modal UI
  async function uploadImageDirect(imageFile, prefix, width) {
    const formData = new FormData();
    formData.append('image', imageFile);
    formData.append('currentPath', getCurrentPath());
    formData.append('prefix', prefix || 'img');
    formData.append('username', getCurrentUsername());

    try {
      const response = await fetch(`${API_URL}/api/images/upload`, {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (data.success) {
        const markdown = formatMarkdown(data.fullUrl, width);
        return { ...data, markdown };
      }
      return null;
    } catch (error) {
      console.error('[Wiki Upload] Direct upload failed:', error);
      return null;
    }
  }

  // Fallback: Use paste event to capture clipboard image
  async function fallbackPasteCapture() {
    return new Promise((resolve, reject) => {
      // Create hidden contenteditable to receive paste
      const pasteTarget = document.createElement('div');
      pasteTarget.contentEditable = true;
      pasteTarget.style.cssText = 'position:fixed;left:-9999px;top:0;width:1px;height:1px;';
      document.body.appendChild(pasteTarget);

      const cleanup = () => {
        document.body.removeChild(pasteTarget);
        document.removeEventListener('paste', handlePaste);
      };

      const handlePaste = async (e) => {
        e.preventDefault();
        const items = e.clipboardData?.items;

        if (items) {
          for (let i = 0; i < items.length; i++) {
            if (items[i].type.indexOf('image') !== -1) {
              const blob = items[i].getAsFile();
              cleanup();
              await processAndInsertImage(blob);
              resolve();
              return;
            }
          }
        }

        cleanup();
        showQuickNotification('No image in clipboard', 'error');
        reject(new Error('No image'));
      };

      document.addEventListener('paste', handlePaste);
      pasteTarget.focus();

      // Trigger paste programmatically
      document.execCommand('paste');

      // Timeout fallback
      setTimeout(() => {
        cleanup();
        reject(new Error('Paste timeout'));
      }, 1000);
    });
  }

  // Show quick notification (toast style)
  function showQuickNotification(message, type) {
    let notification = document.getElementById('wiki-quick-notification');

    if (!notification) {
      notification = document.createElement('div');
      notification.id = 'wiki-quick-notification';
      notification.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        z-index: 10001;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        transition: opacity 0.3s, transform 0.3s;
        transform: translateY(0);
      `;
      document.body.appendChild(notification);
    }

    notification.textContent = message;

    if (type === 'success') {
      notification.style.background = '#4CAF50';
      notification.style.color = 'white';
    } else if (type === 'error') {
      notification.style.background = '#f44336';
      notification.style.color = 'white';
    } else {
      notification.style.background = '#2196F3';
      notification.style.color = 'white';
    }

    notification.style.opacity = '1';
    notification.style.transform = 'translateY(0)';

    // Auto-hide after 2 seconds for success/error
    if (type !== 'loading') {
      setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateY(10px)';
      }, 2000);
    }
  }

  // Browse existing files (uses new ID-based API)
  async function browseExistingFiles() {
    try {
      showStatus('Loading files...', 'loading');

      const currentPath = getCurrentPath();
      // Use new ID-based endpoint
      const response = await fetch(`${API_URL}/api/images/browse?currentPath=${encodeURIComponent(currentPath)}`);
      const data = await response.json();

      const fileBrowser = document.getElementById('file-browser');

      if (data.success && data.files.length > 0) {
        fileBrowser.innerHTML = data.files.map(file => `
          <div class="file-item" data-url="${file.fullUrl}" data-id="${file.id || ''}">
            <div class="file-name">${file.filename}</div>
            <div class="file-date">${new Date(file.uploadedAt).toLocaleString()}${file.untracked ? ' (untracked)' : ''}</div>
          </div>
        `).join('');

        fileBrowser.classList.add('visible');
        showStatus('Found ' + data.count + ' files', 'success');

        // Add click handlers
        fileBrowser.querySelectorAll('.file-item').forEach(item => {
          item.addEventListener('click', function() {
            const url = this.getAttribute('data-url');
            const width = getSelectedWidth();
            const markdown = formatMarkdown(url, width);
            showResult(markdown);
            fileBrowser.classList.remove('visible');
          });
        });
      } else {
        showStatus('No files found for this page', 'error');
        fileBrowser.classList.remove('visible');
      }
    } catch (error) {
      showStatus('Failed to browse files: ' + error.message, 'error');
    }
  }

  // Initialize widget with retry logic
  function init(retryCount = 0) {
    console.log(`[Wiki Upload] Initializing Tampermonkey widget (attempt ${retryCount + 1})...`);
    console.log('[Wiki Upload] Current URL:', window.location.href);

    // Check if widget already exists
    if (document.getElementById('wiki-upload-btn')) {
      console.log('[Wiki Upload] Widget already exists, skipping');
      return;
    }

    // Check if sidebar exists and has buttons
    const sidebar = document.querySelector('.editor-markdown-sidebar');
    if (!sidebar || sidebar.childElementCount < 5) {
      if (retryCount < 10) {
        console.log('[Wiki Upload] Sidebar not ready, retrying in 500ms...');
        setTimeout(() => init(retryCount + 1), 500);
        return;
      } else {
        console.error('[Wiki Upload] Sidebar never loaded after 10 attempts');
        return;
      }
    }

    console.log('[Wiki Upload] Sidebar found with', sidebar.childElementCount, 'children');
    console.log('[Wiki Upload] Creating widget...');

    // Create and insert modal
    const widget = createWidget();
    document.body.appendChild(widget);

    console.log('[Wiki Upload] Modal added to DOM');

    // Create sidebar button matching Wiki.js style
    const sidebarButton = document.createElement('button');
    sidebarButton.type = 'button';
    sidebarButton.id = 'wiki-upload-btn';
    sidebarButton.className = 'mt-3 animated fadeInLeft wait-p2s mx-0 v-btn v-btn--flat v-btn--icon v-btn--round v-btn--tile theme--dark v-size--default';
    sidebarButton.title = 'Upload Image';
    sidebarButton.innerHTML = '<span class="v-btn__content"><i aria-hidden="true" class="v-icon notranslate mdi mdi-image-plus theme--dark"></i></span>';

    // Inject button into sidebar (sidebar already found above)
    // Find the mdi-chart-multiline button (third button)
    const chartButton = sidebar.querySelector('.mdi-chart-multiline');
    if (chartButton && chartButton.closest('button')) {
      // Insert after the chart button
      const targetButton = chartButton.closest('button');
      targetButton.parentNode.insertBefore(sidebarButton, targetButton.nextSibling);
      console.log('[Wiki Upload] Button injected into sidebar after chart button');
    } else {
      // Fallback: insert before the spacer
      const spacer = sidebar.querySelector('.spacer');
      if (spacer) {
        sidebar.insertBefore(sidebarButton, spacer);
        console.log('[Wiki Upload] Button injected into sidebar before spacer');
      } else {
        sidebar.appendChild(sidebarButton);
        console.log('[Wiki Upload] Button appended to sidebar');
      }
    }

    // Set default prefix
    const prefixInput = document.getElementById('upload-prefix');
    prefixInput.value = getCurrentUsername();

    // Button click handler
    sidebarButton.addEventListener('click', showModal);

    // Close button click
    document.getElementById('wiki-upload-close-btn').addEventListener('click', hideModal);

    // ESC key to close modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && document.getElementById('wiki-upload-modal-overlay').classList.contains('visible')) {
        hideModal();
      }
    });

    // Drop zone handlers
    const dropZone = document.getElementById('drop-zone');

    dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropZone.classList.add('drag-over');
    });

    dropZone.addEventListener('dragleave', () => {
      dropZone.classList.remove('drag-over');
    });

    dropZone.addEventListener('drop', async (e) => {
      e.preventDefault();
      dropZone.classList.remove('drag-over');

      const files = e.dataTransfer.files;
      if (files.length > 0 && files[0].type.startsWith('image/')) {
        await uploadImage(files[0], prefixInput.value);
      } else {
        showStatus('Please drop an image file', 'error');
      }
    });

    dropZone.addEventListener('click', () => {
      document.getElementById('file-input').click();
    });

    // Size option handlers
    document.querySelectorAll('.size-option').forEach(option => {
      option.addEventListener('click', () => {
        document.querySelectorAll('.size-option').forEach(o => o.classList.remove('selected'));
        option.classList.add('selected');

        // Update result if already showing
        const resultMarkdown = document.getElementById('result-markdown');
        const resultArea = document.getElementById('result-area');
        if (resultArea.classList.contains('visible') && resultMarkdown.textContent) {
          // Extract URL from current markdown
          const urlMatch = resultMarkdown.textContent.match(/https?:\/\/[^\s\)\"]+/);
          if (urlMatch) {
            const width = option.dataset.width;
            const newMarkdown = formatMarkdown(urlMatch[0], width);
            resultMarkdown.textContent = newMarkdown;
          }
        }
      });
    });

    // Paste area handler
    const pasteArea = document.getElementById('paste-area');

    // Auto-focus paste area when modal opens
    const originalShowModal = showModal;
    showModal = function() {
      originalShowModal();
      setTimeout(() => pasteArea.focus(), 100);
    };

    pasteArea.addEventListener('paste', async (e) => {
      e.preventDefault();

      const items = e.clipboardData.items;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const blob = items[i].getAsFile();
          await uploadImage(blob, prefixInput.value);
          return;
        }
      }

      showStatus('No image found in clipboard', 'error');
    });

    // File input change handler
    document.getElementById('file-input').addEventListener('change', async (e) => {
      const files = e.target.files;
      if (files.length > 0) {
        await uploadImage(files[0], prefixInput.value);
        e.target.value = ''; // Reset input
      }
    });

    // Browse button handler
    document.getElementById('browse-btn').addEventListener('click', browseExistingFiles);

    // Copy button handler
    document.getElementById('copy-btn').addEventListener('click', async () => {
      const markdown = document.getElementById('result-markdown').textContent;
      const copyBtn = document.getElementById('copy-btn');

      const success = await copyToClipboard(markdown);
      if (success) {
        copyBtn.textContent = '✓ Copied!';
        copyBtn.classList.add('copied');
        showStatus('Copied to clipboard!', 'success');

        setTimeout(() => {
          copyBtn.textContent = '📋 Copy';
          copyBtn.classList.remove('copied');
        }, 2000);
      } else {
        showStatus('Failed to copy - please select and copy manually', 'error');
      }
    });

    // Insert at cursor button handler
    document.getElementById('insert-btn').addEventListener('click', () => {
      const markdown = document.getElementById('result-markdown').textContent;
      if (insertAtCursor(markdown)) {
        showStatus('Inserted at cursor!', 'success');
        hideModal();
      } else {
        showStatus('Editor not found - copied to clipboard instead', 'error');
        copyToClipboard(markdown);
      }
    });

    console.log('[Wiki Upload] Widget initialized successfully');
  }

  // Wait for page to be fully loaded, then initialize
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }



  console.log('[Wiki Edit Actions] Script loaded');

  // Insert text directly into CodeMirror.
  // CM5 attaches the editor instance as .CodeMirror on the wrapper element;
  // replaceSelection() inserts at the current cursor position reliably.
  // Falls back to the textarea + execCommand path if the instance isn't available.
  function insertIntoEditor(text) {
    const cmEl = document.querySelector('.CodeMirror');
    if (!cmEl) return false;

    // Preferred: use the CM5 instance directly
    if (cmEl.CodeMirror) {
      cmEl.CodeMirror.focus();
      cmEl.CodeMirror.replaceSelection(text);
      return true;
    }

    const textarea = cmEl.querySelector('textarea');
    if (!textarea) return false;

    textarea.focus();
    const ok = document.execCommand('insertText', false, text);
    if (ok) return true;

    // execCommand fallback: dispatch an InputEvent so CodeMirror picks it up
    const ev = new InputEvent('input', {
      bubbles: true,
      cancelable: true,
      inputType: 'insertText',
      data: text,
    });
    textarea.dispatchEvent(ev);
    return true;
  }

  // Auto-intercept ALL paste events containing images.
  // Ctrl+V with an image auto-uploads and inserts the markdown link at the cursor.
  // Cursor position is captured before the async upload so it is restored correctly
  // even if focus drifts during the network request.

  document.addEventListener('paste', async function(e) {
    const items = e.clipboardData?.items;
    if (!items) return;

    // Check if there's an image in the clipboard
    let imageItem = null;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf('image') !== -1) {
        imageItem = items[i];
        break;
      }
    }

    // No image - let paste proceed normally
    if (!imageItem) return;

    // Image found! Intercept the paste completely
    e.preventDefault();
    e.stopImmediatePropagation();

    // Save CM instance and cursor position BEFORE the async upload so we can
    // restore them after focus may have drifted during the network round-trip.
    const cmEl = document.querySelector('.CodeMirror');
    const cm = cmEl ? cmEl.CodeMirror : null;
    const savedCursor = cm ? cm.getCursor() : null;

    console.log('[Wiki Upload] Image paste intercepted');

    const blob = imageItem.getAsFile();

    showQuickNotification('⏳ Uploading...', 'loading');
    const result = await uploadImageDirect(blob, getCurrentUsername(), '800');

    if (result && result.markdown) {
      if (cm) {
        // Restore cursor position then insert via the CM instance
        cm.focus();
        if (savedCursor) cm.setCursor(savedCursor);
        cm.replaceSelection(result.markdown);
        showQuickNotification('✓ Image inserted!', 'success');
      } else {
        // No CM instance - copy to clipboard and re-focus the textarea so
        // the next Ctrl+V lands in the right place without needing a click.
        await copyToClipboard(result.markdown);
        const textarea = document.querySelector('.CodeMirror textarea');
        if (textarea) textarea.focus();
        showQuickNotification('✓ Link copied! Ctrl+V to paste', 'success');
      }
    } else {
      showQuickNotification('Upload failed', 'error');
    }
  }, true);

  console.log('[Wiki Edit Actions] Auto image paste enabled - Ctrl+V with image auto-uploads');

  // Wait for save completion by watching for UI changes
  function waitForSaveComplete() {
    return new Promise((resolve) => {
      console.log('[Wiki Edit Actions] Waiting for save to complete...');

      // Look for common save indicators (loading overlay, notifications, etc.)
      let checkCount = 0;
      const maxChecks = 50; // 5 seconds max (50 * 100ms)

      const checkInterval = setInterval(() => {
        checkCount++;

        // Check if there's a loading overlay or notification
        const loading = document.querySelector('.v-overlay--active, .loading, .v-progress-circular');
        const notification = document.querySelector('.v-snack--active, .notification');

        if (!loading && checkCount > 5) {
          // No loading indicator and we've waited a bit
          console.log('[Wiki Edit Actions] Save appears complete');
          clearInterval(checkInterval);
          resolve();
        } else if (checkCount >= maxChecks) {
          // Timeout
          console.log('[Wiki Edit Actions] Save timeout, proceeding anyway');
          clearInterval(checkInterval);
          resolve();
        }
      }, 100);
    });
  }

  // Listen for keyboard shortcuts
  document.addEventListener('keydown', async function(e) {
    // Alt+R: Save page then close
    if (e.altKey && (e.key === 'r' || e.key === 'R')) {
      e.preventDefault();

      // Find the save button (green check icon)
      const saveButton = document.querySelector('button .mdi-check.green--text')?.closest('button');

      if (saveButton) {
        console.log('[Wiki Edit Actions] Alt+R - Clicking save button');
        saveButton.click();

        // Wait for save to complete
        await waitForSaveComplete();

        // Now click close
        const closeButton = document.querySelector('button .mdi-close.red--text')?.closest('button');
        if (closeButton) {
          console.log('[Wiki Edit Actions] Save complete - Clicking close button');
          closeButton.click();
        }
      } else {
        console.warn('[Wiki Edit Actions] Save button not found');
      }
    }

    // Alt+X: Close editor (click red X button)
    if (e.altKey && (e.key === 'x' || e.key === 'X')) {
      e.preventDefault();

      // Find the close button (red X icon)
      const closeButton = document.querySelector('button .mdi-close.red--text')?.closest('button');

      if (closeButton) {
        console.log('[Wiki Edit Actions] Alt+X - Clicking close button');
        closeButton.click();
      } else {
        console.warn('[Wiki Edit Actions] Close button not found');
      }
    }
  });

  console.log('[Wiki Edit Actions] Ready - Alt+R to save, Alt+X to close');



  console.log('[Markdown Snippets] Script loaded');

  const SNIPPETS_API_URL = 'http://eapw-105:22001/api/markdown-snippets';
  let snippetsData = null;

  // Fetch snippets from API
  async function fetchSnippets() {
    try {
      const response = await fetch(SNIPPETS_API_URL);
      if (!response.ok) throw new Error('Failed to load snippets');
      const data = await response.json();
      if (data.success) {
        snippetsData = data.data;
        console.log('[Markdown Snippets] Loaded', snippetsData.presets.length, 'snippets');
      }
    } catch (error) {
      console.error('[Markdown Snippets] Error:', error);
    }
  }

  // Create snippet modal
  function createSnippetModal() {
    const modal = document.createElement('div');
    modal.innerHTML = `
      <style>
        #snippet-modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0,0,0,0.5);
          z-index: 10000;
          display: none;
          align-items: center;
          justify-content: center;
        }

        #snippet-modal-overlay.visible {
          display: flex;
        }

        #snippet-modal {
          width: 90%;
          max-width: 800px;
          max-height: 90vh;
          background: #ffffff;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.3);
          overflow: hidden;
          display: flex;
          flex-direction: column;
        }

        #snippet-modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px 20px;
          background: #2196F3;
          color: white;
        }

        #snippet-modal-header h3 {
          margin: 0;
          font-size: 18px;
          font-weight: 600;
        }

        #snippet-close-btn {
          background: none;
          border: none;
          color: white;
          font-size: 28px;
          cursor: pointer;
          padding: 0;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 4px;
          transition: background 0.2s;
        }

        #snippet-close-btn:hover {
          background: rgba(255,255,255,0.2);
        }

        #snippet-modal-body {
          padding: 20px;
          overflow-y: auto;
          flex: 1;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          font-size: 14px;
        }

        .snippet-selector {
          display: grid;
          grid-template-columns: auto 1fr;
          gap: 10px;
          align-items: center;
          margin-bottom: 20px;
        }

        .snippet-selector label {
          font-weight: 600;
          color: #333;
        }

        .snippet-selector select {
          padding: 8px;
          border: 1px solid #ddd;
          border-radius: 6px;
          font-size: 14px;
          background: white;
        }

        .snippet-form {
          margin-bottom: 20px;
        }

        .snippet-field {
          margin-bottom: 15px;
        }

        .snippet-field label {
          display: block;
          font-weight: 600;
          margin-bottom: 5px;
          color: #333;
        }

        .snippet-field input,
        .snippet-field select,
        .snippet-field textarea {
          width: 100%;
          padding: 10px;
          border: 1px solid #ddd;
          border-radius: 6px;
          font-family: inherit;
          font-size: 14px;
          box-sizing: border-box;
        }

        .snippet-field textarea {
          min-height: 80px;
          resize: vertical;
          font-family: 'Courier New', monospace;
        }

        .snippet-no-fields {
          color: #666;
          font-style: italic;
          padding: 10px;
          background: #f9f9f9;
          border-radius: 6px;
        }

        .snippet-preview {
          margin-top: 20px;
        }

        .snippet-preview h4 {
          margin: 0 0 10px 0;
          font-size: 14px;
          font-weight: 600;
          color: #333;
        }

        .snippet-preview pre {
          background: #f5f5f5;
          border: 1px solid #ddd;
          border-radius: 6px;
          padding: 15px;
          overflow-x: auto;
          white-space: pre-wrap;
          font-family: 'Courier New', monospace;
          font-size: 13px;
          max-height: 200px;
          overflow-y: auto;
        }

        #snippet-modal-footer {
          padding: 15px 20px;
          border-top: 1px solid #ddd;
          display: flex;
          justify-content: flex-end;
          gap: 10px;
          background: #f9f9f9;
        }

        .snippet-btn {
          padding: 10px 20px;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-weight: 500;
          font-size: 14px;
          transition: all 0.2s;
        }

        .snippet-btn-cancel {
          background: #f5f5f5;
          color: #333;
          border: 1px solid #ddd;
        }

        .snippet-btn-cancel:hover {
          background: #e0e0e0;
        }

        .snippet-btn-copy {
          background: #2196F3;
          color: white;
        }

        .snippet-btn-copy:hover {
          background: #1976D2;
        }

        .snippet-btn-insert {
          background: #4CAF50;
          color: white;
        }

        .snippet-btn-insert:hover {
          background: #388E3C;
        }
      </style>

      <div id="snippet-modal-overlay">
        <div id="snippet-modal">
          <div id="snippet-modal-header">
            <h3>Insert Markdown Snippet</h3>
            <button id="snippet-close-btn">&times;</button>
          </div>

          <div id="snippet-modal-body">
            <div class="snippet-selector">
              <label>Category:</label>
              <select id="snippet-category">
                <option value="all">All</option>
              </select>
              <label>Template:</label>
              <select id="snippet-template">
                <option value="">Select a template...</option>
              </select>
            </div>
            <div id="snippet-form-container"></div>
            <div class="snippet-preview">
              <h4>Preview</h4>
              <pre id="snippet-preview-content"></pre>
            </div>
          </div>

          <div id="snippet-modal-footer">
            <button class="snippet-btn snippet-btn-cancel" id="snippet-cancel-btn">Cancel</button>
            <button class="snippet-btn snippet-btn-copy" id="snippet-copy-btn">Copy to Clipboard</button>
            <button class="snippet-btn snippet-btn-insert" id="snippet-insert-btn">Insert at Cursor</button>
          </div>
        </div>
      </div>
    `;
    return modal;
  }

  // Populate categories
  function populateCategories() {
    if (!snippetsData) return;
    
    const categories = [...new Set(snippetsData.presets.map(p => p.category))];
    const select = document.getElementById('snippet-category');
    
    categories.forEach(cat => {
      const option = document.createElement('option');
      option.value = cat;
      option.textContent = cat;
      select.appendChild(option);
    });
  }

  // Populate templates based on category
  function populateTemplates(category = 'all') {
    if (!snippetsData) return;
    
    const select = document.getElementById('snippet-template');
    select.innerHTML = '<option value="">Select a template...</option>';
    
    const filtered = category === 'all' 
      ? snippetsData.presets 
      : snippetsData.presets.filter(p => p.category === category);
    
    filtered.forEach(preset => {
      const option = document.createElement('option');
      option.value = preset.id;
      option.textContent = preset.name;
      select.appendChild(option);
    });
  }

  // Render form for selected template
  function renderSnippetForm(templateId) {
    const preset = snippetsData.presets.find(p => p.id === templateId);
    if (!preset) return;
    
    const container = document.getElementById('snippet-form-container');
    
    if (preset.fields.length === 0) {
      container.innerHTML = '<p class="snippet-no-fields">No fields required - template ready to insert</p>';
      updateSnippetPreview(preset.template);
      return;
    }
    
    let html = '<div class="snippet-form">';
    preset.fields.forEach(field => {
      html += `<div class="snippet-field">`;
      html += `<label>${field.label}:</label>`;
      
      if (field.type === 'textarea') {
        html += `<textarea data-field="${field.name}" placeholder="${field.placeholder || ''}"></textarea>`;
      } else if (field.type === 'select') {
        html += `<select data-field="${field.name}">`;
        html += `<option value="">Select...</option>`;
        field.options.forEach(opt => {
          html += `<option value="${opt}">${opt}</option>`;
        });
        html += `</select>`;
      } else {
        html += `<input type="text" data-field="${field.name}" placeholder="${field.placeholder || ''}" />`;
      }
      
      html += `</div>`;
    });
    html += '</div>';
    
    container.innerHTML = html;
    
    // Attach input listeners for live preview
    container.querySelectorAll('[data-field]').forEach(input => {
      input.addEventListener('input', () => updateSnippetPreview(preset.template));
    });
    
    updateSnippetPreview(preset.template);
  }

  // Update preview with current field values
  function updateSnippetPreview(template) {
    const fields = document.querySelectorAll('[data-field]');
    let result = template;
    
    fields.forEach(field => {
      const fieldName = field.getAttribute('data-field');
      const value = field.value || `{${fieldName}}`;
      result = result.replace(new RegExp(`\\{${fieldName}\\}`, 'g'), value);
    });
    
    document.getElementById('snippet-preview-content').textContent = result;
  }

  // Get final markdown output
  function getSnippetMarkdown() {
    return document.getElementById('snippet-preview-content').textContent;
  }

  // Copy to clipboard
  function copySnippetToClipboard() {
    const markdown = getSnippetMarkdown();
    navigator.clipboard.writeText(markdown).then(() => {
      alert('Copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy:', err);
      alert('Failed to copy to clipboard');
    });
  }

  // Insert at cursor in CodeMirror
  function insertSnippetAtCursor() {
    const markdown = getSnippetMarkdown();
    
    // Find CodeMirror editor
    const editor = document.querySelector('.CodeMirror');
    
    if (editor && editor.CodeMirror) {
      editor.CodeMirror.replaceSelection(markdown);
      hideSnippetModal();
      alert('Snippet inserted!');
    } else {
      // Fallback: copy to clipboard
      copySnippetToClipboard();
      alert('Editor not found - copied to clipboard instead');
    }
  }

  // Show/hide snippet modal
  function showSnippetModal() {
    document.getElementById('snippet-modal-overlay').classList.add('visible');
  }

  function hideSnippetModal() {
    document.getElementById('snippet-modal-overlay').classList.remove('visible');
  }

  // Initialize snippets with retry logic
  function initSnippets(retryCount = 0) {
    console.log(`[Markdown Snippets] Initializing (attempt ${retryCount + 1})...`);

    // Check if already initialized
    if (document.getElementById('snippet-modal-overlay')) {
      console.log('[Markdown Snippets] Already initialized');
      return;
    }

    // Check if sidebar exists
    const sidebar = document.querySelector('.editor-markdown-sidebar');
    if (!sidebar || sidebar.childElementCount < 5) {
      if (retryCount < 10) {
        console.log('[Markdown Snippets] Sidebar not ready, retrying in 500ms...');
        setTimeout(() => initSnippets(retryCount + 1), 500);
        return;
      } else {
        console.error('[Markdown Snippets] Sidebar never loaded');
        return;
      }
    }

    console.log('[Markdown Snippets] Sidebar found, creating modal...');

    // Fetch snippets data
    fetchSnippets().then(() => {
      if (!snippetsData) {
        console.error('[Markdown Snippets] Failed to load snippets data');
        return;
      }

      // Create and insert modal
      const modal = createSnippetModal();
      document.body.appendChild(modal);

      console.log('[Markdown Snippets] Modal added to DOM');

      // Populate initial data
      populateCategories();
      populateTemplates();

      // Create sidebar button
      const sidebarButton = document.createElement('button');
      sidebarButton.type = 'button';
      sidebarButton.id = 'snippet-modal-btn';
      sidebarButton.className = 'mt-3 animated fadeInLeft wait-p2s mx-0 v-btn v-btn--flat v-btn--icon v-btn--round v-btn--tile theme--dark v-size--default';
      sidebarButton.title = 'Insert Markdown Snippet';
      sidebarButton.innerHTML = '<span class="v-btn__content"><i aria-hidden="true" class="v-icon notranslate mdi mdi-code-braces theme--dark"></i></span>';

      // Find upload button and insert after it
      const uploadButton = document.getElementById('wiki-upload-btn');
      if (uploadButton) {
        uploadButton.parentNode.insertBefore(sidebarButton, uploadButton.nextSibling);
        console.log('[Markdown Snippets] Button injected after upload button');
      } else {
        // Fallback: insert before spacer
        const spacer = sidebar.querySelector('.spacer');
        if (spacer) {
          sidebar.insertBefore(sidebarButton, spacer);
          console.log('[Markdown Snippets] Button injected before spacer');
        } else {
          sidebar.appendChild(sidebarButton);
          console.log('[Markdown Snippets] Button appended to sidebar');
        }
      }

      // Event listeners
      sidebarButton.addEventListener('click', showSnippetModal);
      document.getElementById('snippet-close-btn').addEventListener('click', hideSnippetModal);
      document.getElementById('snippet-cancel-btn').addEventListener('click', hideSnippetModal);
      document.getElementById('snippet-copy-btn').addEventListener('click', copySnippetToClipboard);
      document.getElementById('snippet-insert-btn').addEventListener('click', insertSnippetAtCursor);

      document.getElementById('snippet-category').addEventListener('change', (e) => {
        populateTemplates(e.target.value);
        document.getElementById('snippet-form-container').innerHTML = '';
        document.getElementById('snippet-preview-content').textContent = '';
      });

      document.getElementById('snippet-template').addEventListener('change', (e) => {
        if (e.target.value) {
          renderSnippetForm(e.target.value);
        }
      });

      // ESC key to close
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && document.getElementById('snippet-modal-overlay').classList.contains('visible')) {
          hideSnippetModal();
        }
      });

      // Ctrl+Shift+M shortcut
      document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.shiftKey && e.key === 'M') {
          e.preventDefault();
          showSnippetModal();
        }
      });

      console.log('[Markdown Snippets] Initialized successfully - Ctrl+Shift+M to open');
    });
  }

  // Initialize snippets after page load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(initSnippets, 1000));
  } else {
    setTimeout(initSnippets, 1000);
  }


})();
