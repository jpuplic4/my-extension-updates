// Navigation Drawer Resize and Collapse Functionality
(() => {
  'use strict';

  console.log('[Wiki Nav Resize] Script loaded');

  // Constants
  const DEFAULT_WIDTH = 256;
  const MIN_WIDTH = 50;
  const MAX_WIDTH = 400;
  const STORAGE_KEY_WIDTH = 'wiki-nav-drawer-width';
  const STORAGE_KEY_COLLAPSED = 'wiki-nav-drawer-collapsed';

  // State
  let isDragging = false;
  let startX = 0;
  let startWidth = 0;
  let mainContentElement = null;

  // Load drawer width from localStorage
  function loadDrawerWidth() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_WIDTH);
      if (stored === null) return DEFAULT_WIDTH;

      const parsed = parseInt(stored, 10);

      // Validate: must be number within bounds
      if (isNaN(parsed)) return DEFAULT_WIDTH;
      if (parsed < MIN_WIDTH || parsed > MAX_WIDTH) return DEFAULT_WIDTH;

      return parsed;
    } catch (e) {
      console.warn('[Wiki Nav Resize] Failed to load drawer width:', e);
      return DEFAULT_WIDTH;
    }
  }

  // Save drawer width to localStorage
  function saveDrawerWidth(width) {
    try {
      localStorage.setItem(STORAGE_KEY_WIDTH, String(width));
    } catch (e) {
      console.warn('[Wiki Nav Resize] Failed to save drawer width:', e);
    }
  }

  // Load collapsed state from localStorage
  function loadCollapsedState() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_COLLAPSED);
      return stored === 'true';
    } catch (e) {
      console.warn('[Wiki Nav Resize] Failed to load collapsed state:', e);
      return false;
    }
  }

  // Save collapsed state to localStorage
  function saveCollapsedState(isCollapsed) {
    try {
      localStorage.setItem(STORAGE_KEY_COLLAPSED, String(isCollapsed));
    } catch (e) {
      console.warn('[Wiki Nav Resize] Failed to save collapsed state:', e);
    }
  }

  // Find main content element (cache it)
  function getMainContentElement() {
    if (mainContentElement) return mainContentElement;

    // Try different selectors in priority order
    mainContentElement = document.querySelector('.v-main') ||
                        document.querySelector('.v-content') ||
                        document.querySelector('main');

    return mainContentElement;
  }

  // Apply drawer width and adjust main content margin
  function applyDrawerWidth(navDrawer, width, animated) {
    if (!navDrawer) return;

    // Clamp width to bounds
    width = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, width));

    // Update drawer width
    navDrawer.style.width = width + 'px';

    // Find main content element
    const mainContent = getMainContentElement();
    if (mainContent) {
      // Calculate margin difference from default
      const marginDelta = width - DEFAULT_WIDTH;
      const newMargin = DEFAULT_WIDTH + marginDelta;
      mainContent.style.marginLeft = newMargin + 'px';

      // Add/remove resizing class for transition control
      if (!animated) {
        navDrawer.classList.add('resizing');
        mainContent.classList.add('resizing');
        // Remove class after a tick to re-enable transitions
        setTimeout(() => {
          navDrawer.classList.remove('resizing');
          mainContent.classList.remove('resizing');
        }, 0);
      }
    }

    // Add/remove collapsed class
    if (width === MIN_WIDTH) {
      navDrawer.classList.add('collapsed');
    } else {
      navDrawer.classList.remove('collapsed');
    }
  }

  // Mouse down handler - start resize
  function handleMouseDown(e, navDrawer, border) {
    e.preventDefault();

    isDragging = true;
    startX = e.clientX;
    startWidth = navDrawer.offsetWidth;

    // Disable transitions during drag
    navDrawer.classList.add('resizing');
    const mainContent = getMainContentElement();
    if (mainContent) {
      mainContent.classList.add('resizing');
    }

    // Add dragging class to border
    border.classList.add('dragging');

    // Prevent text selection during drag
    document.body.style.cursor = 'ew-resize';
    document.body.style.userSelect = 'none';

    // Disable pointer events on drawer content during drag
    navDrawer.style.pointerEvents = 'none';

    // Add document-level listeners (not border-level)
    const mouseMoveHandler = (e) => handleMouseMove(e, navDrawer, startX, startWidth);
    const mouseUpHandler = (e) => handleMouseUp(e, navDrawer, border, mouseMoveHandler, mouseUpHandler);

    document.addEventListener('mousemove', mouseMoveHandler);
    document.addEventListener('mouseup', mouseUpHandler);
  }

  // Mouse move handler - update width
  function handleMouseMove(e, navDrawer, startX, startWidth) {
    if (!isDragging) return;

    // Use requestAnimationFrame for smooth 60fps updates
    requestAnimationFrame(() => {
      const delta = e.clientX - startX;
      let newWidth = startWidth + delta;

      // Apply width with bounds checking
      applyDrawerWidth(navDrawer, newWidth, false);
    });
  }

  // Mouse up handler - end resize
  function handleMouseUp(e, navDrawer, border, mouseMoveHandler, mouseUpHandler) {
    if (!isDragging) return;

    isDragging = false;

    // Re-enable transitions
    navDrawer.classList.remove('resizing');
    const mainContent = getMainContentElement();
    if (mainContent) {
      mainContent.classList.remove('resizing');
    }

    // Remove dragging class from border
    border.classList.remove('dragging');

    // Restore cursor and text selection
    document.body.style.cursor = '';
    document.body.style.userSelect = '';

    // Re-enable pointer events
    navDrawer.style.pointerEvents = '';

    // Remove document-level listeners
    document.removeEventListener('mousemove', mouseMoveHandler);
    document.removeEventListener('mouseup', mouseUpHandler);

    // Save final width to localStorage
    const finalWidth = navDrawer.offsetWidth;
    saveDrawerWidth(finalWidth);

    // Update collapsed state
    saveCollapsedState(finalWidth === MIN_WIDTH);
  }

  // Debounce utility function
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // Create toggle button
  function createToggleButton(navDrawer) {
    const toggleBtn = document.createElement('div');
    toggleBtn.className = 'wiki-nav-toggle-btn';
    toggleBtn.innerHTML = '«';
    toggleBtn.title = 'Toggle navigation drawer';

    toggleBtn.addEventListener('click', () => {
      const currentWidth = navDrawer.offsetWidth;
      const isCollapsed = currentWidth === MIN_WIDTH;

      if (isCollapsed) {
        // Expand to saved width or default
        const savedWidth = loadDrawerWidth();
        applyDrawerWidth(navDrawer, savedWidth, true);
        saveCollapsedState(false);
        toggleBtn.innerHTML = '«';
      } else {
        // Collapse to minimum width
        applyDrawerWidth(navDrawer, MIN_WIDTH, true);
        saveCollapsedState(true);
        toggleBtn.innerHTML = '»';
      }
    });

    // Position button on drawer
    navDrawer.style.position = 'relative';
    navDrawer.appendChild(toggleBtn);

    // Set initial icon based on state
    const isCollapsed = loadCollapsedState();
    toggleBtn.innerHTML = isCollapsed ? '»' : '«';
  }

  // Initialize resize functionality
  function initResizableDrawer(navDrawer) {
    // Find the border element
    const border = navDrawer.querySelector('.v-navigation-drawer__border');
    if (!border) {
      console.warn('[Wiki Nav Resize] Border element not found');
      return;
    }

    // Add mousedown listener to border
    border.addEventListener('mousedown', (e) => handleMouseDown(e, navDrawer, border));

    console.log('[Wiki Nav Resize] Resize functionality initialized');
  }

  // Inject resize styles
  function injectResizeStyles() {
    const style = document.createElement('style');
    style.textContent = `
      /* Resize handle styling */
      .v-navigation-drawer__border {
        width: 4px !important;
        background: rgba(255, 255, 255, 0.1) !important;
        cursor: ew-resize !important;
        transition: background 0.2s !important;
        z-index: 10 !important;
      }

      .v-navigation-drawer__border:hover {
        background: rgba(255, 255, 255, 0.3) !important;
      }

      .v-navigation-drawer__border.dragging {
        background: rgba(76, 175, 80, 0.5) !important;
      }

      /* Smooth width transitions - Material Design easing */
      .v-navigation-drawer {
        transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
      }

      .v-main {
        transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
      }

      /* Disable transitions during active drag */
      .v-navigation-drawer.resizing,
      .v-main.resizing {
        transition: none !important;
      }

      /* Collapsed state */
      .v-navigation-drawer.collapsed .folder-name,
      .v-navigation-drawer.collapsed .page-name {
        display: none !important;
      }

      /* Toggle button */
      .wiki-nav-toggle-btn {
        position: absolute;
        top: 50%;
        right: -12px;
        width: 24px;
        height: 48px;
        background: rgba(76, 175, 80, 0.9);
        border-radius: 0 8px 8px 0;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 16px;
        z-index: 11;
        transition: background 0.2s;
        box-shadow: 2px 0 4px rgba(0,0,0,0.2);
        user-select: none;
      }

      .wiki-nav-toggle-btn:hover {
        background: rgba(76, 175, 80, 1);
      }
    `;
    document.head.appendChild(style);
    console.log('[Wiki Nav Resize] Styles injected');
  }

  // Initialize resize functionality
  async function init(retryCount = 0) {
    console.log(`[Wiki Nav Resize] Initializing (attempt ${retryCount + 1})...`);

    // Find the navigation drawer
    const navDrawer = document.querySelector('.v-navigation-drawer');
    if (!navDrawer) {
      if (retryCount < 10) {
        console.log('[Wiki Nav Resize] Navigation drawer not found, retrying in 500ms...');
        setTimeout(() => init(retryCount + 1), 500);
        return;
      } else {
        console.error('[Wiki Nav Resize] Navigation drawer never loaded');
        return;
      }
    }

    console.log('[Wiki Nav Resize] Navigation drawer found');

    // Inject styles
    injectResizeStyles();

    // Load saved state
    const savedWidth = loadDrawerWidth();
    const isCollapsed = loadCollapsedState();

    // Apply saved width (or collapsed state)
    if (isCollapsed) {
      applyDrawerWidth(navDrawer, MIN_WIDTH, false);
    } else {
      applyDrawerWidth(navDrawer, savedWidth, false);
    }

    // Initialize resize functionality
    initResizableDrawer(navDrawer);

    // Create toggle button
    createToggleButton(navDrawer);

    // Add window resize listener with debounce
    window.addEventListener('resize', debounce(() => {
      const currentWidth = navDrawer.offsetWidth;
      applyDrawerWidth(navDrawer, currentWidth, false);
    }, 250));

    // Add storage event listener for multi-tab sync
    window.addEventListener('storage', (e) => {
      if (e.key === STORAGE_KEY_WIDTH) {
        const newWidth = loadDrawerWidth();
        applyDrawerWidth(navDrawer, newWidth, true);
      }
      if (e.key === STORAGE_KEY_COLLAPSED) {
        const isCollapsed = loadCollapsedState();
        applyDrawerWidth(navDrawer, isCollapsed ? MIN_WIDTH : loadDrawerWidth(), true);
      }
    });

    console.log('[Wiki Nav Resize] Initialization complete');
  }

  // Start initialization
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
